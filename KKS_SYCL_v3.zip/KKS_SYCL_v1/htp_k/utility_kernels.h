#ifndef UTILITYKERNELS_CUH_
#define UTILITYKERNELS_CUH_

#include "pfm_global.h"
using namespace PFM::DTYPE ;

class computeChange_kernel
{
public:
    fp_scalar *A;
    fp_scalar *B;
    integer DIMENSION;
    integer sizeX;
    integer sizeY;
    integer sizeZ;
    computeChange_kernel(){}

};

class resetArray_kernel
{
public:
    fp_scalar **arr;
    integer numArr;
    integer DIMENSION;
    integer sizeX;
    integer sizeY;
    integer sizeZ;
    resetArray_kernel(
        fp_scalar **_arr, integer _numArr, integer _DIMENSION, integer _sizeX, integer _sizeY, integer _sizeZ)
            :arr(_arr),
            numArr(_numArr),
            DIMENSION(_DIMENSION),
            sizeX(_sizeX),
            sizeY(_sizeY),
            sizeZ(_sizeZ) {}

    template<typename syclidtype>
    void operator() (syclidtype ID) const {
        integer k = ID[0],
            j  = ID[1],
            i  = ID[2];
        
        integer idx = (j + i*sizeY)*sizeZ + k;

        if (i < sizeX && ((j < sizeY && DIMENSION >= 2) || (DIMENSION == 1 && j == 0)) && ((k < sizeZ && DIMENSION == 3) || (DIMENSION < 3 && k == 0)))
        {
            for (integer iter = 0; iter < numArr; iter++)
                arr[iter][idx] = 0.0;
        }
        
    }

};





#endif