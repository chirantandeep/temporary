#ifndef UPDATEPHI_CUH_
#define UPDATEPHI_CUH_

#include "structures.h"
#include "functionA_01.h"
#include "functionTau.h"


#include "pfm_global.h"
using namespace PFM::DTYPE ;

#define phiAniso(phase, x, y, z) (phiAniso[(((phase)*3 + (x))*3 + (y))*3 + (z)])


class updatePhi_kernel{
public:
    fp_scalar **phi;
    fp_scalar **dfdphi;
    fp_scalar **phiNew;
    fp_scalar *relaxCoeff;
    fp_scalar *kappaPhi;
    fp_scalar *dab;
    fp_scalar *Rotation_matrix ;
    fp_scalar *Inv_rotation_matrix;
    int FUNCTION_ANISOTROPY;
    integer NUMPHASES;
    integer NUMCOMPONENTS;
    integer DIMENSION;
    integer FUNCTION_F;
    integer sizeX; 
    integer sizeY; 
    integer sizeZ;
    integer xStep; 
    integer yStep; 
    integer padding;
    fp_scalar DELTA_X;
    fp_scalar DELTA_Y; 
    fp_scalar DELTA_Z;
    fp_scalar DELTA_t;

    updatePhi_kernel(fp_scalar **_phi, fp_scalar **_dfdphi, fp_scalar **_phiNew, fp_scalar **_phaseComp, domainInfo* simDomain, controls* simControls, simParameters* simParams, subdomainInfo* subdomain)
    :   phi(_phi),
        dfdphi(_dfdphi),
        phiNew(_phiNew),
        relaxCoeff(simParams->relax_coeff_dev),
        kappaPhi(simParams->kappaPhi_dev),
        dab(simParams->dab_dev),
        Rotation_matrix(simParams->Rotation_matrix_dev),
        Inv_rotation_matrix(simParams->Inv_Rotation_matrix_dev),
        FUNCTION_ANISOTROPY(simControls->FUNCTION_ANISOTROPY),
        NUMPHASES(simDomain->numPhases),
        NUMCOMPONENTS(simDomain->numComponents),
        DIMENSION(simDomain->DIMENSION), 
        FUNCTION_F(simControls->FUNCTION_F),
        sizeX(subdomain->sizeX), 
        sizeY(subdomain->sizeY),
        sizeZ(subdomain->sizeZ),
        xStep(subdomain->xStep), 
        yStep(subdomain->yStep),
        padding(subdomain->padding),
        DELTA_X(simDomain->DELTA_X), 
        DELTA_Y(simDomain->DELTA_Y), 
        DELTA_Z(simDomain->DELTA_Z),
        DELTA_t(simControls->DELTA_t){}

    
    void operator() (sycl::item<3> ID) const {
    integer i = ID[2] + padding ;
    integer j = ID[1] + padding ;
    integer k = ID[0] + padding ;

    integer x, y, z;

    integer index[3][3][3];

    fp_scalar phiAniso[MAX_NUM_PHASES*27];

    fp_scalar divphi[MAX_NUM_PHASES] = {0.0};

    fp_scalar aniso[MAX_NUM_PHASES] = {0.0};
    fp_scalar dfdphiSum = 0.0;

    integer phase, p;

    int interface = 1;

    /*
        * index is a 3D matrix that stores location indices for the ...
        * 26 gridpoints around the gridpoint at which computation is being carried out.
        *
        * Eg:
        * index[0][1][2] is (i-1, j, k+1)
        *
        * for 2D simulations, the third index will be set to 1 (index[x][y][1])
        *
        */

    for (x = 0; x < 3; x++)
    {
        for (y = 0; y < 3; y++)
        {
            for (z = 0; z < 3; z++)
            {
                index[x][y][z] = (k+z-1) + (j+y-1)*yStep + (i+x-1)*xStep;
            }
        }
    }

    for (phase = 0; phase < NUMPHASES; phase++)
    {
        for (x = 0; x < 3; x++)
        {
            for (y = 0; y < 3; y++)
            {
                if (DIMENSION == 3)
                {
                    for (z = 0; z < 3; z++)
                    {
                        phiAniso(phase, x, y, z) = phi[phase][index[x][y][z]];
                    }
                }
                else
                {
                    phiAniso(phase, x, y, 1) = phi[phase][index[x][y][1]];
                }
            }
        }
    }

    if (FUNCTION_F != 2)
    {
        for (phase = 0; phase < NUMPHASES; phase++)
        {
            // Determine if interfacial point
            divphi[phase] = (phiAniso(phase, 2, 1, 1) - 2.0*phiAniso(phase, 1, 1, 1) + phiAniso(phase, 0, 1, 1))/(DELTA_X*DELTA_X);
            divphi[phase] += (phiAniso(phase, 1, 2, 1) - 2.0*phiAniso(phase, 1, 1, 1) + phiAniso(phase, 1, 0, 1))/(DELTA_Y*DELTA_Y);
            divphi[phase] += (phiAniso(phase, 1, 1, 2) - 2.0*phiAniso(phase, 1, 1, 1) + phiAniso(phase, 1, 1, 0))/(DELTA_Z*DELTA_Z);

            if (phiAniso(phase, 1, 1, 1) > 1e-3 && phiAniso(phase, 1, 1, 1) < 1.0-1e-3)
            {
                interface = 1;
                break;
            }

            if (sycl::fabs(divphi[phase]) < 1e-3/(DELTA_X)){
                interface = 0;
            }
                
        }
    }

if (interface)
    {
        if (FUNCTION_ANISOTROPY == 0)
        {
            for (phase = 0; phase < NUMPHASES; phase++)
            {
                // Centre
                aniso[phase] = -4.0*phiAniso(phase, 1, 1, 1)/(DELTA_X*DELTA_X);

                // Nearest neighbours
                aniso[phase] += (phiAniso(phase, 0, 1, 1) + phiAniso(phase, 2, 1, 1))/(3.0*DELTA_X*DELTA_X);
                aniso[phase] += (phiAniso(phase, 1, 0, 1) + phiAniso(phase, 1, 2, 1))/(3.0*DELTA_Y*DELTA_Y);
                aniso[phase] += (phiAniso(phase, 1, 1, 0) + phiAniso(phase, 1, 1, 2))/(3.0*DELTA_Z*DELTA_Z);

                // Second-nearest neighbours
                aniso[phase] += (phiAniso(phase, 0, 0, 1) + phiAniso(phase, 0, 2, 1) + phiAniso(phase, 2, 2, 1) + phiAniso(phase, 2, 0, 1))/(6.0*DELTA_X*DELTA_Y);
                aniso[phase] += (phiAniso(phase, 1, 0, 0) + phiAniso(phase, 1, 0, 2) + phiAniso(phase, 1, 2, 2) + phiAniso(phase, 1, 2, 0))/(6.0*DELTA_Y*DELTA_Z);
                aniso[phase] += (phiAniso(phase, 0, 1, 0) + phiAniso(phase, 0, 1, 2) + phiAniso(phase, 2, 1, 2) + phiAniso(phase, 2, 1, 0))/(6.0*DELTA_Z*DELTA_X);
            
            }
        }
        else if (FUNCTION_ANISOTROPY == 1 || FUNCTION_ANISOTROPY == 2)
        {
            for (phase = 0; phase < NUMPHASES; phase++)
            {
                aniso[phase] = calcAnisotropy_01(phiAniso, dab, kappaPhi, Rotation_matrix, Inv_rotation_matrix, phase, NUMPHASES, DIMENSION, DELTA_X, DELTA_Y, DELTA_Z);
            }
        }

        for (phase = 0; phase < NUMPHASES; phase++)
        {
            dfdphiSum = 0.0;

            for (p = 0; p < NUMPHASES; p++)
            {
                if (p == phase)
                    continue;

                dfdphiSum += (dfdphi[phase][index[1][1][1]] - dfdphi[p][index[1][1][1]]);

                if (FUNCTION_ANISOTROPY == 0)
                {
                    dfdphiSum += 2.0*kappaPhi[phase*NUMPHASES + p]*(aniso[p] - aniso[phase]);
                }
                else if (FUNCTION_ANISOTROPY == 1 || FUNCTION_ANISOTROPY == 2)
                {
                    dfdphiSum += 2.0*(aniso[p] - aniso[phase]);
                }
            }
            fp_scalar val = phi[phase][index[1][1][1]] - DELTA_t*FunctionTau(phi, relaxCoeff, index[1][1][1], NUMPHASES)*dfdphiSum/(fp_scalar)NUMPHASES ;
            //val = val > 1.0 ? 1.0 : val ;
            //val = val < 0.0 ? 0.0 : val ;
            phiNew[phase][index[1][1][1]] = val;
        }
    }
}

};





#endif