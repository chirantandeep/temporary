#ifndef CALCPHASECOMP_CUH_
#define CALCPHASECOMP_CUH_

#include "structures.h"
//#include "utilityKernels.cuh"
//#include "Thermo.h"
#include "matrix.h"
//#include "functionF.h"
#include "functionH.h"

#include "pfm_global.h"
using namespace PFM::DTYPE ;

class calcPhaseComp_kernel{
public:
    integer FUNCTION_F ;
    integer count ;
    fp_scalar **phi;
    fp_scalar **comp;
    fp_scalar **phaseComp;
    fp_scalar **mu;
    fp_scalar *cguess;
    fp_scalar *F0_A;
    fp_scalar *F0_B;
    fp_scalar *F0_C;
    integer *thermo_phase;
    fp_scalar temperature_eq;
    fp_scalar temperature ;
    integer NUMPHASES; 
    integer NUMCOMPONENTS; 
    integer DIMENSION;
    integer sizeX; 
    integer sizeY; 
    integer sizeZ;
    integer xStep; 
    integer yStep; 
    integer padding;

    // has error
    calcPhaseComp_kernel(fp_scalar **_phi, fp_scalar **_comp, fp_scalar **_phaseComp, fp_scalar **_mu, domainInfo* _simDomain, controls* _simControls, simParameters* _simParams, subdomainInfo* _subdomain)
        :   FUNCTION_F(_simControls->FUNCTION_F),
            count(_simControls->count),
            phi(_phi),
            comp(_comp),
            phaseComp(_phaseComp),
            mu(_mu),
            cguess(_simParams->cguess_dev),
            F0_A(_simParams->F0_A_dev),
            F0_B(_simParams->F0_B_dev),
            F0_C(_simParams->F0_C_dev),
            thermo_phase(_simDomain->thermo_phase_dev),
            temperature_eq(_simParams->Teq),
            temperature (_simParams->T),
            NUMPHASES(_simDomain->numPhases), 
            NUMCOMPONENTS(_simDomain->numComponents), 
            DIMENSION(_simDomain->DIMENSION),
            sizeX(_subdomain->sizeX), 
            sizeY(_subdomain->sizeY), 
            sizeZ(_subdomain->sizeZ),
            xStep(_subdomain->xStep), 
            yStep(_subdomain->yStep), 
            padding(_subdomain->padding){ };


    template<typename syclidtype>
    inline void calcPhaseComp_01(syclidtype  ID) const
    {
        integer i = ID[2] + padding;
        integer j = ID[1] + padding;
        integer k = ID[0] + padding;

        integer idx = i*xStep + j*yStep + k;

        // Number of phase compositions
        integer N = NUMPHASES*(NUMCOMPONENTS-1);

        // Iterate to fill jacobian and function vector
        integer iter1, iter2, iter3, iter4;
        integer index1, index2;

        // Delta vector, function vector, jacobian matrix
        fp_scalar sol[MAX_NUM_PHASE_COMP], B[MAX_NUM_PHASE_COMP];
        fp_scalar A[MAX_NUM_PHASE_COMP][MAX_NUM_PHASE_COMP];

        // Permutation matrix required for LUP linear system solver
        int P[MAX_NUM_PHASE_COMP+1];

        // Tolerance for LU solver
        fp_scalar tol = 1e-10;

        // Calculate function vector using x^n
        for (iter1 = 0; iter1 < NUMCOMPONENTS-1; iter1++)
        {
            for (iter2 = 0; iter2 < NUMPHASES; iter2++)
            {
                index1 = iter2 + iter1*NUMPHASES;
                if (iter2)
                {
                    // Constant part (linear part of free-energy) taken to the RHS of AX = B
                    // B^{K}_{P+1} - B^{K}_{P}
                    B[index1] = F0_B[iter1 + iter2*(NUMCOMPONENTS-1)] - F0_B[iter1 + (iter2-1)*(NUMCOMPONENTS-1)];
                }
                else
                {
                    // Composition conservation equation
                    B[index1] = comp[iter1][idx];
                }
            }
        }

        // Calculate jacobian using x^n
        for (iter1 = 0; iter1 < NUMCOMPONENTS-1; iter1++)
        {
            for (iter2 = 0; iter2 < NUMPHASES; iter2++)
            {
                index1 = iter2 + iter1*NUMPHASES;
                if (iter2)
                {
                    for (iter3 = 0; iter3 < NUMCOMPONENTS-1; iter3++)
                    {
                        for (iter4 = 0; iter4 < NUMPHASES; iter4++)
                        {
                            index2 = iter4 + iter3*NUMPHASES;

                            if (iter4 == iter2-1)
                            {
                                if (iter3 == iter1)
                                    A[index1][index2] = 2.0*F0_A[(iter3 + iter4*(NUMCOMPONENTS-1))*(NUMCOMPONENTS-1) + iter1];
                                else
                                    A[index1][index2] = F0_A[(iter3 + iter4*(NUMCOMPONENTS-1))*(NUMCOMPONENTS-1) + iter1];
                            }
                            else if (iter4 == iter2)
                            {
                                if (iter3 == iter1)
                                    A[index1][index2] = -2.0*F0_A[(iter3 + iter4*(NUMCOMPONENTS-1))*(NUMCOMPONENTS-1) + iter1];
                                else
                                    A[index1][index2] = -1.0*F0_A[(iter3 + iter4*(NUMCOMPONENTS-1))*(NUMCOMPONENTS-1) + iter1];
                            }
                            else
                                A[index1][index2] = 0.0;
                        }
                    }
                } // if (iter2)
                else
                {
                    for (iter3 = 0; iter3 < NUMCOMPONENTS-1; iter3++)
                    {
                        for (iter4 = 0; iter4 < NUMPHASES; iter4++)
                        {
                            index2 = iter4 + iter3*NUMPHASES;

                            if (iter3 == iter1)
                                A[index1][index2] = calcInterp5th(phi, iter4, idx, NUMPHASES);
                            else
                                A[index1][index2] = 0.0;
                        }
                    }
                }
            } // for (iter2 = 0 ... )
        } // for (iter1 = 0 ... )

        // Get x^(n+1) - x^(n)
        LUPDecomposePC1(A, N, tol, P);
        LUPSolvePC1(A, P, B, N, sol);
        fp_scalar val;

        for (iter1 = 0; iter1 < N; iter1++)
        {
            // Update phase composition
            val = sol[iter1] ;
            //val = val > 1.0 ? 1.0 : val ;
            //val = val < 0.0 ? 0.0 : val ;
            phaseComp[iter1][idx] = val;
        }

    }

/*
    template<typename syclidtype>
    inline void initMu(syclidtype  ID) const
    {
        integer i = ID[2];
        integer j = ID[1];
        integer k = ID[0];

        integer idx = i*xStep + j*yStep + k;

        if (i < sizeX && ((j < sizeY && DIMENSION >= 2) || (DIMENSION == 1 && j == 0)) && ((k < sizeZ && DIMENSION == 3) || (DIMENSION < 3 && k == 0)))
        {
            fp_scalar y[MAX_NUM_COMP], mu0[MAX_NUM_COMP];
            fp_scalar sum = 0.0;

            for (integer phase = 0; phase < NUMPHASES; phase++)
            {
                // Bulk
                if (phi[phase][idx] == 1.0)
                {
                    sum = 0.0;

                    for (integer i = 0; i < NUMCOMPONENTS-1; i++)
                    {
                        phaseComp[phase + NUMPHASES*i][idx] = comp[i][idx];
                        y[i] = comp[i][idx];
                        sum += y[i];
                    }

                    y[NUMCOMPONENTS-1] = 1.0 - sum;
                    MuF(phase,temperature_eq, y, mu0);
                    //???(*Mu_tdb_dev[phase])(temperature_eq, y, mu0);

                    for (integer i = 0; i < NUMCOMPONENTS-1; i++)
                        mu[i][idx] = mu0[i];
                }
                else
                {
                    for (integer i = 0; i < NUMCOMPONENTS-1; i++)
                        phaseComp[phase + NUMPHASES*i][idx] = 0.0;
                }
            }
        }
    }

    template<typename syclidtype>
    inline void calcPhaseComp_02(syclidtype  ID) const
    {
        integer i = ID[2];
        integer j = ID[1];
        integer k = ID[0];

        integer idx = i*xStep + j*yStep + k;

        if (i < sizeX && ((j < sizeY && DIMENSION >= 2) || (DIMENSION == 1 && j == 0)) && ((k < sizeZ && DIMENSION == 3) || (DIMENSION < 3 && k == 0)))
        {
            fp_scalar fun[MAX_NUM_COMP], jacInv[MAX_NUM_COMP][MAX_NUM_COMP], cn[MAX_NUM_COMP], co[MAX_NUM_COMP];
            fp_scalar tmp0, norm;
            fp_scalar retdmuphase[MAX_NUM_COMP*MAX_NUM_COMP], retdmuphase2[MAX_NUM_COMP][MAX_NUM_COMP], y[MAX_NUM_COMP], mu0[MAX_NUM_COMP];

            fp_scalar tol = 1e-6;

            integer interface = 1;
            integer bulkphase;

            for (integer is = 0; is < NUMPHASES; is++)
            {
                if (phi[is][idx] > 0.99999)
                {
                    bulkphase = is;
                    interface = 0;
                    break;
                }
            }

            if (interface)
            {
                // Number of iterations for Newton-Raphson
                integer count = 0;
                // Number of iterations for diffusion-potential correction
                integer count2 = 0;

                integer is, is1, is2;
                integer maxCount = 10000;

                // Permutation matrix required by LU decomposition routine
                int P[MAX_NUM_COMP];

                fp_scalar dmudc[(MAX_NUM_COMP)*(MAX_NUM_COMP)];
                fp_scalar dcdmu[(MAX_NUM_COMP)*(MAX_NUM_COMP)];
                fp_scalar Inv[MAX_NUM_COMP][MAX_NUM_COMP];

                fp_scalar deltac[MAX_NUM_COMP] = {0.0};
                integer deltac_flag = 0;

                do
                {
                    count2++;

                    for (integer phase = 0; phase < NUMPHASES; phase++)
                    {
                        for (is = 0; is < NUMCOMPONENTS-1; is++)
                        {
                            cn[is] = cguess[(phase + phase*(NUMPHASES))*(NUMCOMPONENTS-1) + is];
                        }

                        do
                        {
                            count++;

                            tmp0 = 0.0;

                            // Getting phase-compositions at the node
                            for (is = 0; is < NUMCOMPONENTS-1; is++)
                            {
                                co[is] = cn[is];
                                y[is]  = co[is];
                                tmp0  += co[is];
                            }
                            y[NUMCOMPONENTS-1] = 1.0 - tmp0;

                            // Getting local diffusion potential from tdb function
                            MuF(phase,temperature_eq, y, mu0);
                            //????(*Mu_tdb_dev[phase])(temperature, y, mu0);

                            // Deviation of mu obtained from evolution from mu obtained from tdb
                            for (is = 0; is < NUMCOMPONENTS-1; is++)
                                fun[is] = (mu0[is] - mu[is][idx]);

                            // Second derivative of free-energy
                            dmudcF(phase, temperature, y, retdmuphase);
                            //????(*dmudc_tdb_dev[phase])(temperature, y, retdmuphase);

                            // Translating 2D array to 1D
                            for (is1 = 0; is1 < NUMCOMPONENTS-1; is1++)
                            {
                                for (is2 = 0; is2 < NUMCOMPONENTS-1; is2++)
                                {
                                    retdmuphase2[is1][is2] = retdmuphase[is1*(NUMCOMPONENTS-1) + is2];
                                }
                            }

                            // Inverting dmudc to get dcdmu
                            LUPDecomposeC1(retdmuphase2, NUMCOMPONENTS-1, tol, P);
                            LUPInvertC1(retdmuphase2, P, NUMCOMPONENTS-1, jacInv);

                            // Newton-Raphson (-J^{-1}F)
                            for (is1 = 0; is1 < NUMCOMPONENTS-1; is1++)
                            {
                                tmp0 = 0.0;
                                for (is2 = 0; is2 < NUMCOMPONENTS-1; is2++)
                                {
                                    tmp0 += jacInv[is1][is2] * fun[is2];
                                }

                                cn[is1] = co[is1] - tmp0;
                            }

                            // L-inf norm
                            norm = 0.0;
                            for (is = 0; is < NUMCOMPONENTS-1; is++)
                                if (fabs(cn[is] - co[is]) > 1e-6)
                                    norm = 1.0;
                        } while (count < maxCount && norm > 0.0);

                        for (is = 0; is < NUMCOMPONENTS-1; is++)
                            phaseComp[is*NUMPHASES + phase][idx] = cn[is];
                    }

                    // Check conservation of comp
                    deltac_flag = 0;
                    for (is = 0; is < NUMCOMPONENTS-1; is++)
                    {
                        deltac[is] = 0.0;

                        for (int phase = 0; phase < NUMPHASES; phase++)
                        {
                            deltac[is] += phaseComp[is*NUMPHASES + phase][idx]*calcInterp5th(phi, phase, idx, NUMPHASES);
                        }

                        deltac[is] = comp[is][idx] - deltac[is];

                        if (fabs(deltac[is]) > 1e-6)
                            deltac_flag = 1;
                    }

                    // deltac_flag will be 1 if not conserved
                    // mu-correction will be carried out consequently, and the Newton-Raphson routine will be repeated

                    if (deltac_flag)
                    {
                        for (int component = 0; component < NUMCOMPONENTS-1; component++)
                        {
                            for (int component2 = 0; component2 < NUMCOMPONENTS-1; component2++)
                            {
                                dcdmu[component*(NUMCOMPONENTS-1) + component2] = 0.0;
                            }
                        }

                        for (integer phase = 0; phase < NUMPHASES; phase++)
                        {
                            fp_scalar sum = 0.0;

                            for (integer component = 0; component < NUMCOMPONENTS-1; component++)
                            {
                                y[component] = phaseComp[component*NUMPHASES + phase][idx];
                                sum += y[component];
                            }

                            y[NUMCOMPONENTS-1] = 1.0 - sum;
                            
                            dmudcF(phase, temperature, y, dmudc);
                            //???(*dmudc_tdb_dev[phase])(temperature, y, dmudc);

                            LUPDecomposeC2(dmudc, NUMCOMPONENTS-1, tol, P);
                            LUPInvertC2(dmudc, P, NUMCOMPONENTS-1, Inv);

                            for (integer component = 0; component < NUMCOMPONENTS-1; component++)
                                for (integer component2 = 0; component2 < NUMCOMPONENTS-1; component2++)
                                    dcdmu[component*(NUMCOMPONENTS-1) + component2] += calcInterp5th(phi, phase, idx, NUMPHASES)*Inv[component][component2];
                        }

                        LUPDecomposeC2(dcdmu, NUMCOMPONENTS-1, tol, P);
                        LUPInvertC2(dcdmu, P, NUMCOMPONENTS-1, Inv);

                        for (int component = 0; component < NUMCOMPONENTS-1; component++)
                        {
                            for (int component2 = 0; component2 < NUMCOMPONENTS-1; component2++)
                            {
                                mu[component][idx] += Inv[component][component2]*deltac[component2];
                            }
                        }
                    }
                } while (count2 < 1000 && deltac_flag);
            }
            else
            {
                for (integer component = 0; component < NUMCOMPONENTS-1; component++)
                {
                    for (integer phase = 0; phase < NUMPHASES; phase++)
                    {
                        if (phase == bulkphase)
                            phaseComp[bulkphase + NUMPHASES*component][idx] = comp[component][idx];
                        else
                            phaseComp[phase + NUMPHASES*component][idx] = 0.0;
                    }
                }
            }
        }
    }


    template<typename syclidtype>
    void operator() (syclidtype  ID) const {
    
        if (FUNCTION_F == 1 || FUNCTION_F == 3 || FUNCTION_F == 4){
            calcPhaseComp_01(ID) ;
        }else if (FUNCTION_F == 2){
            if (count == 0){
            initMu(ID) ;
            }
            calcPhaseComp_02(ID) ;
        }
    }
*/
    
    template<typename syclidtype>
    void operator() (syclidtype  ID) const {
        calcPhaseComp_01(ID) ;
    }

};



#endif