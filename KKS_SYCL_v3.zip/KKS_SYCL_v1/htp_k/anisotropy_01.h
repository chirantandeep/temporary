#ifndef ANISOTROPY_01_CUH_
#define ANISOTROPY_01_CUH_

#include "pfm_global.h"
using namespace PFM::DTYPE ;

void anisotropy_01_dAdq(fp_scalar *qab, fp_scalar *dadq, integer a, integer b, fp_scalar *dab, integer NUMPHASES)
{
    integer X = 0, Y = 1, Z = 2;

    fp_scalar qx3 = qab[X]*qab[X]*qab[X];
    fp_scalar qy3 = qab[Y]*qab[Y]*qab[Y];
    fp_scalar qz3 = qab[Z]*qab[Z]*qab[Z];

    fp_scalar q2  = qab[X]*qab[X] + qab[Y]*qab[Y] + qab[Z]*qab[Z];
    fp_scalar q22 = q2*q2;
    fp_scalar q23 = q2*q2*q2;
    fp_scalar q4  = qx3*qab[X] + qy3*qab[Y] + qz3*qab[Z];

    if (q2)
    {
        dadq[X] = 16.0*dab[a*NUMPHASES + b]*(qx3/q22 - qab[X]*q4/q23);
        dadq[Y] = 16.0*dab[a*NUMPHASES + b]*(qy3/q22 - qab[Y]*q4/q23);
        dadq[Z] = 16.0*dab[a*NUMPHASES + b]*(qz3/q22 - qab[Z]*q4/q23);
    }
    else
    {
        dadq[X] = 0.0;
        dadq[Y] = 0.0;
        dadq[Z] = 0.0;
    }
}


fp_scalar anisotropy_01_function_ac(fp_scalar *qab, integer a, integer b, fp_scalar *dab, integer NUMPHASES)
{
    integer X = 0, Y = 1, Z = 2;

    fp_scalar qx2 = qab[X]*qab[X];
    fp_scalar qx4 = qx2*qx2;

    fp_scalar qy2 = qab[Y]*qab[Y];
    fp_scalar qy4 = qy2*qy2;

    fp_scalar qz2 = qab[Z]*qab[Z];
    fp_scalar qz4 = qz2*qz2;

    fp_scalar q2  = qx2 + qy2 + qz2;
    fp_scalar ac;

    if (q2)
    {
        ac = 1.0 - dab[a*NUMPHASES + b]*(3.0 - 4.0*(qx4 + qy4 + qz4)/(q2*q2));
    }
    else
    {
        ac = 1.0;
    }

    return ac;
}

#endif