#ifndef INITIALIZE_VARIABLES_H_
#define INITIALIZE_VARIABLES_H_

#include "pfm_global.h"

#include "functionTau.h"
#include "structures.h"
#include "utilityFunctions.h"
#include "utility.h"
using namespace utility ;
using namespace PFM::GLOBAL ;
using namespace PFM::DTYPE ;
/*
 *  All simulation constants are calculated here using parameters read from the input file
 *
 *  Since device-side data is best stored in 1-D contiguous arrays, the data transfer is also done here
 *  in an element-by-element manner.
 */
inline void moveParamsToCPU(sycl::queue q, domainInfo *simDomain, controls *simControls, simParameters *simParams)
{
    std::cout << "- Moving parameters to Device\tstart\n";

    // Calculate kappa, theta
    for (int i = 0; i < simDomain->numPhases; i++)
    {
        simParams->theta_i_host[i] = 0.0;

        for (int j = 0; j < simDomain->numPhases; j++)
        {
            if (i != j)
            {
                simParams->kappaPhi_host[i][j] =  (3.0*simParams->gamma_host[i][j]*simParams->epsilon) /(2.0*simParams->alpha);
                simParams->theta_ij_host[i][j] = 6.0 * simParams->alpha * simParams->gamma_host[i][j] / simParams->epsilon;
            }
            else
            {
                simParams->kappaPhi_host[i][j] = 0.0;
                simParams->theta_ij_host[i][j] = 0.0;
            }
        }
    }

    simControls->antiTrapping = 1;

    // for (int i = 0; i < simDomain->numPhases; i++)
    // {
    //     for (int j = 0; j < simDomain->numComponents-1; j++)
    //     {
    //         for (int k = 0; k < simDomain->numComponents-1; k++)
    //         {
    //             if (simParams->diffusivity_host[i][j][k] == 0.0)
    //             {
    //                 simControls->antiTrapping = 1;
    //             }
    //         }
    //     }
    // }

    // Eigen-strain
    for (int i = 0; i < simDomain->numPhases; i++)
    {
        if (simParams->eigen_strain[i].xx == 0.0 && simParams->eigen_strain[i].yy == 0.0 && simParams->eigen_strain[i].zz == 0.0 && simParams->eigen_strain[i].xy == 0.0 && simParams->eigen_strain[i].xz == 0.0 && simParams->eigen_strain[i].yz == 0.0)
        {
            simControls->eigenSwitch[i] = 0;

        }
        else
        {
            simControls->eigenSwitch[i] = 1;
        }
    }

    // Calculate phase-field mobility
    calculateTau(simDomain, simControls, simParams);
    std::cout << "- calculateTau done!\n";

    size_t np = simDomain->numPhases ;
    size_t nc = simDomain->numComponents ;

    //q.submit([&](sycl::handler& h) {
    //h.single_task([=](){
    int i, j, k, l ;
    for(i = 0 ; i < np ; i ++){
        simDomain->thermo_phase_dev[i] = simDomain->thermo_phase_host[i] ;
        simParams->F0_C_dev        [i] = simParams->F0_C_host        [i] ;
        simParams->theta_i_dev     [i] = simParams->theta_i_host     [i] ;
    for(j = 0 ; j < np ; j ++){
        simParams->gamma_dev      [i*np +j] = simParams->gamma_host      [i][j] ;
        simParams->relax_coeff_dev[i*np +j] = simParams->relax_coeff_host[i][j] ;
        simParams->theta_ij_dev   [i*np +j] = simParams->theta_ij_host   [i][j] ;
        simParams->kappaPhi_dev   [i*np +j] = simParams->kappaPhi_host   [i][j] ;
        simParams->dab_dev        [i*np +j] = simParams->dab_host        [i][j] ;
    for (k = 0; k < 3; k++){
    for (l = 0; l < 3; l++){
        simParams->Rotation_matrix_dev     [((i*np + j)*3 + k)*3 + l] = simParams->Rotation_matrix_host    [i][j][k][l] ;
        simParams->Inv_Rotation_matrix_dev [((i*np + j)*3 + k)*3 + l] = simParams->Inv_Rotation_matrix_host[i][j][k][l] ;
    }} // k, l loop
    for (k = 0; k < np; k++){
        simParams->theta_ijk_host[i][j][k] *= (6.0*simParams->alpha)/simParams->epsilon;
        simParams->theta_ijk_dev[(i*np + j)*np + k] = simParams->theta_ijk_host[i][j][k] ;
    } // k loop
    for (k = 0; k < nc-1; k++){
        simParams->ceq_dev   [(i*np + j)*(nc-1) +k] = simParams->ceq_host   [i][j][k];
        simParams->cfill_dev [(i*np + j)*(nc-1) +k] = simParams->cfill_host [i][j][k];
        simParams->cguess_dev[(i*np + j)*(nc-1) +k] = simParams->cguess_host[i][j][k];
    } // k loop
    } // j loop
    for (j = 0; j < nc-1; j++){
        simParams->F0_B_dev[i*(nc-1) + j] = simParams->F0_B_host[i][j];
    for (k = 0; k < nc-1; k++){
        simParams->mobility_dev     [(i*(nc-1) + j)*(nc-1) + k] = simParams->mobility_host    [i][j][k];
        simParams->diffusivity_dev  [(i*(nc-1) + j)*(nc-1) + k] = simParams->diffusivity_host [i][j][k];
        simParams->F0_A_dev         [(i*(nc-1) + j)*(nc-1) + k] = simParams->F0_A_host        [i][j][k];
    } // k loop
    } // j loop
    } // i loop

    //});}).wait();


    std::ofstream ofs(DEV_DATA_FILE);
    
    nc = nc -1 ;

    printDevArr(q, simDomain->thermo_phase_dev, np, "thermo_phase_dev", ofs);

    printDevArr(q, simParams->gamma_dev, np*np, "gamma_dev", ofs);
    printDevArr(q, simParams->relax_coeff_dev,  np*np, "relax_coeff_dev", ofs);
    printDevArr(q, simParams->kappaPhi_dev, np*np, "kappaPhi_dev", ofs);
    printDevArr(q, simParams->dab_dev, np*np, "dab_dev", ofs);
    printDevArr(q, simParams->mobility_dev, np*nc*nc, "mobility_dev",   ofs);
    printDevArr(q, simParams->diffusivity_dev , np*nc*nc, "diffusivity_dev", ofs);

    printDevArr(q, simParams->theta_i_dev, np, "theta_i_dev", ofs);
    printDevArr(q, simParams->theta_ij_dev, np*np, "theta_ij_dev", ofs);
    printDevArr(q, simParams->theta_ijk_dev, np*np*np, "theta_ijk_dev", ofs);
    
    printDevArr(q, simParams->ceq_dev, np*np*nc, "ceq_dev", ofs);
    printDevArr(q, simParams->cfill_dev, np*np*nc, "cfill_dev", ofs);
    printDevArr(q, simParams->cguess_dev, np*np*nc, "cguess_dev", ofs);

    printDevArr(q, simParams->F0_A_dev, np*nc*nc, "F0_A_dev", ofs);
    printDevArr(q, simParams->F0_B_dev, np*nc, "F0_B_dev", ofs);
    printDevArr(q, simParams->F0_C_dev, np, "F0_C_dev", ofs);
    
    printDevArr(q, simParams->Rotation_matrix_dev, np*np*3*3, "Rotation_matrix_dev", ofs);
    printDevArr(q, simParams->Inv_Rotation_matrix_dev, np*np*3*3, "Inv_Rotation_matrix_dev", ofs);


    std::cout << "- Moving parameters to Device\tdone\n";
}


/*
 *  Distributing the domain to all the MPI processes
 *  The subdomain local and global coordinates will be initialized here
 *  Each worker will be assigned its respective neighbours in this function
 *  Decomposition is presently only done in 1 dimension (slab)
 */
void decomposeDomain(domainInfo simDomain, controls *simControls, subdomainInfo *subdomain,
                     int rank, int size)
{
    std::cout << "- Domain decomposition\tstart\n";
    // Assign subdomain its rank
    subdomain->rank = 0; // ??
    subdomain->size = 1;
    subdomain->padding = simControls->padding;

    /*
     * In 3-D, decomposition is done along the z-axis
     */
    if (simDomain.DIMENSION == 3)
    {
        // z-axis
        subdomain->zS = 0;
        subdomain->zE = simDomain.MESH_Z;

        subdomain->zS_c = 0;
        subdomain->zE_c = simDomain.MESH_Z + 2*subdomain->padding;

        subdomain->zS_r = subdomain->padding;
        subdomain->zE_r = simDomain.MESH_Z + subdomain->padding;

        subdomain->numZ = subdomain->zE - subdomain->zS ;
        subdomain->sizeZ = subdomain->zE_c - subdomain->zS_c;
        subdomain->numCells = subdomain->numZ;
        subdomain->numCompCells = subdomain->sizeZ;

        // y-axis
        subdomain->yS = 0;
        subdomain->yE = simDomain.MESH_Y;

        subdomain->yS_c = 0;
        subdomain->yE_c = simDomain.MESH_Y + 2*subdomain->padding;

        subdomain->yS_r = subdomain->padding;
        subdomain->yE_r = simDomain.MESH_Y + subdomain->padding;

        subdomain->numY = subdomain->yE - subdomain->yS;
        subdomain->sizeY = subdomain->yE_c - subdomain->yS_c;
        subdomain->numCells *= subdomain->numY;
        subdomain->numCompCells *= subdomain->sizeY;
    }
    else if (simDomain.DIMENSION == 2)
    {
        // z-axis
        subdomain->zS = 0;
        subdomain->zE = 1;

        subdomain->zS_c = 0;
        subdomain->zE_c = 1;

        subdomain->zS_r = 0;
        subdomain->zE_r = 1;

        subdomain->numZ = subdomain->zE - subdomain->zS;
        subdomain->sizeZ = subdomain->zE_c - subdomain->zS_c;
        subdomain->numCells = subdomain->numZ;
        subdomain->numCompCells = subdomain->sizeZ;

        // y-axis
        subdomain->yS = 0;
        subdomain->yE = simDomain.MESH_Y;

        subdomain->yS_c = 0;
        subdomain->yE_c = simDomain.MESH_Y + 2*subdomain->padding;

        subdomain->yS_r = subdomain->padding;
        subdomain->yE_r = simDomain.MESH_Y + subdomain->padding;

        subdomain->numY = subdomain->yE - subdomain->yS;
        subdomain->sizeY = subdomain->yE_c - subdomain->yS_c;
        subdomain->numCells *= subdomain->numY;
        subdomain->numCompCells *= subdomain->sizeY;

    }
    else if (simDomain.DIMENSION == 1)
    {
        // z-axis
        subdomain->zS = 0;
        subdomain->zE = 1;

        subdomain->zS_c = 0;
        subdomain->zE_c = 1;

        subdomain->zS_r = 0;
        subdomain->zE_r = 1;

        subdomain->numZ = subdomain->zE - subdomain->zS;
        subdomain->sizeZ = subdomain->zE_c - subdomain->zS_c;
        subdomain->numCells = subdomain->numZ;
        subdomain->numCompCells = subdomain->sizeZ;

        // y-axis
        subdomain->yS = 0;
        subdomain->yE = 1;

        subdomain->yS_c = 0;
        subdomain->yE_c = 1;

        subdomain->yS_r = 0;
        subdomain->yE_r = 1;

        subdomain->numY = subdomain->yE - subdomain->yS;
        subdomain->sizeY = subdomain->yE_c - subdomain->yS_c;
        subdomain->numCells *= subdomain->numY;
        subdomain->numCompCells *= subdomain->sizeY;
    }

    // Decomposing along the x-axis
    int ranks_cutoff = simDomain.MESH_X % size;
    size_t my_nx = (simDomain.MESH_X / size) + (rank < ranks_cutoff ? 1 : 0);

    if (size > 1)
        subdomain->xS = (rank < ranks_cutoff ? rank*my_nx : ranks_cutoff*(my_nx+1) + (rank - ranks_cutoff)*my_nx);
    else
        subdomain->xS = 0;

    subdomain->xE = subdomain->xS + my_nx;

    subdomain->xS_c = 0;
    subdomain->xE_c = my_nx + 2*subdomain->padding;

    subdomain->xS_r = subdomain->padding;
    subdomain->xE_r = my_nx + subdomain->padding;

    subdomain->numX = subdomain->xE - subdomain->xS;
    subdomain->sizeX = subdomain->xE_c - subdomain->xS_c;
    subdomain->numCells *= subdomain->numX;
    subdomain->numCompCells *= subdomain->sizeX;

    subdomain->shiftPointer = simControls->padding*subdomain->sizeY*subdomain->sizeZ;

    subdomain->xStep = subdomain->sizeY*subdomain->sizeZ;
    subdomain->yStep = subdomain->sizeZ;
    subdomain->zStep = 1;

    // Setting neighbours for every block
    if (rank == 0 && size)
    {
        subdomain->nbBack = size - 1;
        subdomain->nbFront = rank + 1;
    }
    else if (rank == size - 1 && size)
    {
        subdomain->nbBack = rank - 1;
        subdomain->nbFront = 0;
    }
    else if (size)
    {
        subdomain->nbBack = rank - 1;
        subdomain->nbFront = rank + 1;
    }
    else
    {
        subdomain->nbBack = 0;
        subdomain->nbFront = 0;
    }

    printf("- Size: (%ld, %ld, %ld)\n", subdomain->sizeX, subdomain->sizeY, subdomain->sizeZ);
    printf("- Boundary: (x: (%ld, %ld), y:(%ld, %ld), z:(%ld, %ld))\n", subdomain->xS, subdomain->xE, subdomain->yS, subdomain->yE, subdomain->zS, subdomain->zE);
    printf("- Computational Boundary: (x: (%ld, %ld), y:(%ld, %ld), z:(%ld, %ld))\n", subdomain->xS_c, subdomain->xE_c, subdomain->yS_c, subdomain->yE_c, subdomain->zS_c, subdomain->zE_c);
    printf("- Steps: (%ld, %ld, %ld)\n", subdomain->xStep, subdomain->yStep, subdomain->zStep);
    printf("- Num. Cells: %ld\n- Num. Comp. Cells: %ld\n- Shift Pointer: %ld\n", subdomain->numCells, subdomain->numCompCells, subdomain->shiftPointer);

    std::cout << "- Domain decomposition\tdone!\n";
}




#endif