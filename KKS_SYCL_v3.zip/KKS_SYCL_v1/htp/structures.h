#ifndef STRUCTURES_H_
#define STRUCTURES_H_

#include "defines.h"
#include "pfm_global.h"
using namespace PFM::DTYPE ;
/*
 * Definition for a structure to hold information about the domain.
 */
typedef struct domainInfo
{
    // Domain size
    integer MESH_X;
    integer MESH_Y;
    integer MESH_Z;

    integer numCells;

    // Cell size
    fp_scalar DELTA_X;
    fp_scalar DELTA_Y;
    fp_scalar DELTA_Z;

    integer DIMENSION;

    integer numPhases;
    integer numComponents;
    char **phaseNames;
    char **componentNames;

    integer numThermoPhases;
    char **phases_tdb;
    char **phase_map;
    integer  *thermo_phase_dev, *thermo_phase_host;
} domainInfo;

/*
 * Definition for a structure to boundary condition instructions
 */
typedef struct bc_scalars
{
    int type;
    integer points[3];
    integer proxy[3];
    fp_scalar value[3];
} bc_scalars;

/*
 * Definition for a structure to hold simulation controls
 */
typedef struct controls
{
    // MPI information
    integer numworkers;

    // Simulation parameters
    fp_scalar DELTA_t;
    integer startTime;
    integer count;

    // Number of iterations for all of the following
    integer numSteps;
    integer saveInterval;
    integer trackProgress;
    integer restart;
    integer nsmooth;

    // Extent of padding at the block boundaries
    integer padding;

    // Type of free-energy
    integer FUNCTION_F;

    // MPMC or binary
    integer multiphase;

    // Filewriting
    integer writeFormat;
    integer writeHDF5;

    // Anisotropy
    int FUNCTION_ANISOTROPY;
    int FOLD;
    int ANISOTROPY;
    int ANISOTROPY_GRADIENT;
    fp_scalar Rth_phase;

    // Temperature behaviour
    integer ISOTHERMAL;
    fp_scalar dTdt;
    integer T_update;

    // Boundary conditions
    bc_scalars *boundary[6];

    // Antitrapping
    int antiTrapping;

    // Elasticity Switch
    int ELASTICITY;
    // Keeps an account of phase-field variables that have non-zero eigen-strain
    // Zero eigen-strain -> no computation required
    int *eigenSwitch;
} controls;

typedef struct symmetric_tensor
{
    fp_scalar xx;
    fp_scalar yy;
    fp_scalar zz;
    fp_scalar yz;
    fp_scalar xz;
    fp_scalar xy;
} symmetric_tensor;

typedef struct Stiffness_cubic
{
    fp_scalar C11;
    fp_scalar C12;
    fp_scalar C44;
} Stiffness_cubic;

typedef struct simParameters
{
    // User input
    fp_scalar **gamma_host, *gamma_dev;
    fp_scalar ***diffusivity_host, *diffusivity_dev;
    fp_scalar ***mobility_host, *mobility_dev;
    fp_scalar **Tau_host;
    fp_scalar **relax_coeff_host, *relax_coeff_dev;
    fp_scalar ***F0_A_host, *F0_A_dev;
    fp_scalar **F0_B_host, *F0_B_dev;
    fp_scalar **F0_Beq_host, *F0_Beq_dev;
    fp_scalar *F0_C_host, *F0_C_dev;

    integer ISOTHERMAL;

    fp_scalar **DELTA_T;
    fp_scalar **DELTA_C;
    fp_scalar ***dcbdT;
    fp_scalar **dBbdT;

    fp_scalar alpha;
    fp_scalar epsilon;
    fp_scalar ***ceq_host, *ceq_dev;
    fp_scalar ***cfill_host, *cfill_dev;
    fp_scalar ***cguess_host, *cguess_dev;

    fp_scalar R;
    fp_scalar molarVolume;
    fp_scalar T, Teq, Tfill;

    fp_scalar ***slopes;

    fp_scalar *theta_i_host, *theta_i_dev;
    fp_scalar **theta_ij_host, *theta_ij_dev;
    fp_scalar ***theta_ijk_host, *theta_ijk_dev;

    integer SEED;

    fp_scalar **dab_host, *dab_dev;
    fp_scalar tilt_angle;
    fp_scalar Rtheta;
    fp_scalar ****Rotation_matrix_host, *Rotation_matrix_dev;
    fp_scalar ****Inv_Rotation_matrix_host, *Inv_Rotation_matrix_dev;

    // Calculated from user input
    fp_scalar **kappaPhi_host, *kappaPhi_dev;

    // Elasticity variables
    symmetric_tensor *eigen_strain;
    Stiffness_cubic  *Stiffness_c;
} simParameters;

/*
 * Definition for a structure to hold information about the domain that is
 * stored in any particular MPI process
 */
typedef struct subdomainInfo
{
    // Physical
    integer xS, yS, zS;
    integer xE, yE, zE;
    integer numX, numY, numZ;
    integer numCells;

    // Computational
    integer xS_c, yS_c, zS_c;      //Including boundary and communication layer
    integer xE_c, yE_c, zE_c;      //Including boundary and communication layer
    integer xS_r, yS_r, zS_r;      //Map of physical to computational
    integer xE_r, yE_r, zE_r;      //Map of physical to computational
    integer sizeX, sizeY, sizeZ;
    integer numCompCells;

    integer shiftPointer;
    integer padding;
    integer xStep, yStep, zStep;

    int rank, size;

    int nbLeft, nbRight;        //Ainteger x-axis
    int nbUp, nbDown;           //Ainteger y-axis
    int nbFront, nbBack;        //Ainteger z-axis
} subdomainInfo;

/*
 * Definition for a structure to hold sphere filling information
 */
typedef struct sphere
{
    integer xC, yC, zC;
    integer radius;
    integer phase;
} sphere;

/*
 * Definition for a structure to hold cylinder filling information
 */
typedef struct cylinder
{
    integer xC, yC;
    integer zS, zE;
    integer radius;
    integer phase;
} cylinder;

/*
 * Definition for a structure to hold cube filling information
 */
typedef struct cube
{
    integer xS, yS, zS;
    integer xE, yE, zE;
    integer phase;
} cube;

/*
 * Definition for a structure to hold ellipse filling information
 */
typedef struct ellipse
{
    integer xC, yC, zC;
    fp_scalar major_axis;
    fp_scalar eccentricity;
    fp_scalar rot_angle;
    integer phase;
} ellipse;

enum fill{FILLCYLINDER, FILLSPHERE, FILLCYLINDERRANDOM, FILLSPHERERANDOM, FILLCUBE, FILLELLIPSE};

/*
 * Definition for a structure to hold all domain filling information
 */
typedef struct fillParameters
{
    enum fill *fillType;
    integer *xC, *yC, *zC;
    integer *xS, *yS, *zS;
    integer *xE, *yE, *zE;
    integer *radius;
    integer *phase;
    fp_scalar *major_axis, *eccentricity, *rot_angle;
    integer *seed;
    fp_scalar *volFrac;
    integer *shieldDist;
    fp_scalar *radVar;

    integer countFill;
} fillParameters;

#endif
