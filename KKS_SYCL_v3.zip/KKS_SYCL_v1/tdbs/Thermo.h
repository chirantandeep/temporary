/******************************************************************************
 *                       Code generated with sympy 1.8                        *
 *                                                                            *
 *              See http://www.sympy.org/ for more information.               *
 *                                                                            *
 *                       This file is part of 'project'                       *
 ******************************************************************************/


#ifndef PROJECT__TDBS_THERMO__H
#define PROJECT__TDBS_THERMO__H

template<typename dt_scalar>
inline void GE_0(dt_scalar T, dt_scalar *y, dt_scalar *Ge);

template<typename dt_scalar>
inline void GE_1(dt_scalar T, dt_scalar *y, dt_scalar *Ge);

template<typename dt_scalar>
inline void Mu_0(dt_scalar T, dt_scalar *y, dt_scalar *Mu);

template<typename dt_scalar>
inline void Mu_1(dt_scalar T, dt_scalar *y, dt_scalar *Mu);

template<typename dt_scalar>
inline void dmudc_0(dt_scalar T, dt_scalar *y, dt_scalar *Dmudc);

template<typename dt_scalar>
inline void dmudc_1(dt_scalar T, dt_scalar *y, dt_scalar *Dmudc);

template<typename dt_scalar>
inline void GEF(size_t s, dt_scalar T, dt_scalar *y, dt_scalar *Ge){
    if(s == 0){
        GE_0(T, y, Ge) ;
    }else{
        GE_1(T, y, Ge) ;
    }
}
template<typename dt_scalar>
inline void MuF(size_t s, dt_scalar T, dt_scalar *y, dt_scalar *Mu){
    if(s == 0){
        Mu_0(T, y, Mu) ;
    }else{
        Mu_1(T, y, Mu) ;
    }
}
template<typename dt_scalar>
inline void dmudcF(size_t s, dt_scalar T, dt_scalar *y, dt_scalar *Dmudc){
    if(s == 0){
        dmudc_0(T, y, Dmudc) ;
    }else{
        dmudc_1(T, y, Dmudc) ;
    }
}

//inline void(*free_energy_tdb[])(dt_scalar T, dt_scalar *y, dt_scalar *Ge) = {GE_0,GE_1}; 
//inline void(*Mu_tdb[])(dt_scalar T, dt_scalar *y, dt_scalar *Mu) = {Mu_0,Mu_1}; 
//inline void(*dmudc_tdb[])(dt_scalar T, dt_scalar *y, dt_scalar *Dmudc) = {dmudc_0,dmudc_1};

#include "Thermo.cpp"

#endif   

