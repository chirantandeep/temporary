#ifndef PFM_GLOBAL_FILE_H
#define PFM_GLOBAL_FILE_H

#include <iostream>
#include <map>
#include <string>
#include <vector>

namespace PFM{

enum class DEVICE_TYPE {INTEL_CPU, INTEL_GPU , NVIDIA_GPU};
namespace DEVICE{
    DEVICE_TYPE TYPE ;
    bool    is_iCPU = false ,
            is_iGPU = false ,
            is_nGPU = false ;
}

namespace GLOBAL{
std::string OUTPUT_PATH   = "./DATA",
            INPUT_FILE    = "./Infile.in",
            FILLING_FILE  = "./Filling.in",
            PROFILE_FILE  , 
            BOUNDARY_FILE ,
            READ_INP_FILE ,
            DEV_DATA_FILE ,
            OUT_DATA_FILE ;
}

namespace DTYPE{
    typedef float fp_scalar ; // floating point scalar
    typedef long integer ;
}

}

void PFM_Init(int * argc, char *** argv){
    std::cout   << "\n## void PFM_Init(int num_args, char ** arr_args)" ; 
    int num_args = argc[0] ;
    char ** arr_args = argv[0] ;

    if(num_args < 3){
    std::cout << "\nERROR: Provided less than 3 arguments" ;
    std::cout << "\n       See correct usage in \n" ;
    std::exit(0);
    
    }else if( num_args >= 3){
    PFM::GLOBAL::INPUT_FILE    = arr_args[1] ;
    PFM::GLOBAL::FILLING_FILE  = arr_args[1] ;
    PFM::GLOBAL::OUTPUT_PATH   = arr_args[2] ;
    mkdir(arr_args[2], 0777);
    PFM::GLOBAL::PROFILE_FILE  = PFM::GLOBAL::OUTPUT_PATH + "/time_profile.csv";
    PFM::GLOBAL::BOUNDARY_FILE = PFM::GLOBAL::OUTPUT_PATH + "/boundaries.out";
    PFM::GLOBAL::READ_INP_FILE = PFM::GLOBAL::OUTPUT_PATH + "/read_input.out";
    PFM::GLOBAL::OUT_DATA_FILE = PFM::GLOBAL::OUTPUT_PATH + "/out_data";
    PFM::GLOBAL::DEV_DATA_FILE = PFM::GLOBAL::OUTPUT_PATH + "/device_data.out";;

    std::cout << "\nPFM::GLOBAL::INPUT_FILE   =" << PFM::GLOBAL::INPUT_FILE
        << "\nPFM::GLOBAL::FILLING_FILE =" << PFM::GLOBAL::FILLING_FILE
        << "\nPFM::GLOBAL::OUTPUT_PATH  =" << PFM::GLOBAL::OUTPUT_PATH
        << "\nPFM::GLOBAL::PROFILE_FILE =" << PFM::GLOBAL::PROFILE_FILE
        << "\nPFM::GLOBAL::BOUNDARY_FILE=" << PFM::GLOBAL::BOUNDARY_FILE
        << "\nPFM::GLOBAL::READ_INP_FILE=" << PFM::GLOBAL::READ_INP_FILE
        << "\nPFM::GLOBAL::DEV_DATA_FILE=" << PFM::GLOBAL::DEV_DATA_FILE
        << "\nPFM::GLOBAL::OUT_DATA_FILE=" << PFM::GLOBAL::OUT_DATA_FILE ;

    if (num_args >= 4){
        if( 0 == strcasecmp("intel-cpu", arr_args[3]) ){
            PFM::DEVICE::TYPE = PFM::DEVICE_TYPE::INTEL_CPU ;
            std::cout << "\nPFM::DEVICE::TYPE=INTEL_CPU";
        }else if( 0 == strcasecmp("intel-gpu", arr_args[3]) ){
            PFM::DEVICE::TYPE = PFM::DEVICE_TYPE::INTEL_GPU ;
            std::cout << "\nPFM::DEVICE::TYPE=INTEL_GPU";
        }else if( 0 == strcasecmp("nvidia-gpu", arr_args[3]) ){
            PFM::DEVICE::TYPE = PFM::DEVICE_TYPE::NVIDIA_GPU ;
            std::cout << "\nPFM::DEVICE::TYPE=NVIDIA_GPU";
        }else{
            std::cout << "\nERROR: Invalid device name" ;
            std::cout << "\n       " << arr_args[3] << "\n" ;
            std::cout << "Deaulting to PFM::DEVICE_TYPE::INTEL_CPU\n" ;
            PFM::DEVICE::TYPE = PFM::DEVICE_TYPE::INTEL_CPU ;
            std::cout << "\nPFM::DEVICE::TYPE=INTEL_CPU";
        }
    }else{ 
        std::cout << "\nIgnoring arguments" ;
        for(int i=4; i< num_args-1; i++){
            std::cout << arr_args[i] <<" " ;
        }
        std::cout << "\n";
    }

    }
    std::cout << "\n";

    PFM::DEVICE::is_iCPU = PFM::DEVICE::TYPE == PFM::DEVICE_TYPE::INTEL_CPU ;
    PFM::DEVICE::is_iGPU = PFM::DEVICE::TYPE == PFM::DEVICE_TYPE::INTEL_GPU ;
    PFM::DEVICE::is_nGPU = PFM::DEVICE::TYPE == PFM::DEVICE_TYPE::NVIDIA_GPU ;

    std::cout   << "## void PFM_Init done!\n" ; 
}


#endif