#ifndef allochfile
#define allochfile
#include "pfm_global.h"

namespace alloc{

/******************************
 * std based alloc functions
*/

template<typename dt_type>
dt_type* allocate(size_t s1){
    dt_type *F = (dt_type *)std::malloc(s1*sizeof(dt_type));
    for(int i=0;i<s1;i++){
        F[i] = 0 ;
    }
    return F ;
}

template<typename dt_type>
dt_type** allocate(size_t s1, size_t s2){
    dt_type **F = (dt_type **)std::malloc(s1*sizeof(dt_type*));
    for(int i=0;i<s1;i++){
        F[i] = allocate<dt_type>(s2);
    }
    return F ;
}

template<typename dt_type>
dt_type*** allocate(size_t s1, size_t s2, size_t s3){
    dt_type ***F = (dt_type ***)std::malloc(s1*sizeof(dt_type**));
    for(int i=0;i<s1;i++){
        F[i] = allocate<dt_type>(s2,s3);
    }
    return F ;
}

template<typename dt_type>
dt_type**** allocate(size_t s1, size_t s2, size_t s3, size_t s4){
    dt_type ****F = (dt_type ****)std::malloc(s1*sizeof(dt_type***));
    for(int i=0;i<s1;i++){
        F[i] = allocate<dt_type>(s2,s3,s4);
    }
    return F ;
}

template<typename dt_type>
void deallocate(dt_type** F, size_t s1){
    for(int i=0;i<s1;i++){
        free(F[i]);
    }
    free(F);
    F = NULL ;
}

template<typename dt_type>
void deallocate(dt_type*** F, size_t s1, size_t s2){
    size_t i, j;
    for (i = 0; i <s1; i++){
        for (j = 0; j < s2; j++){
            free(F[i][j]);
        }
        free(F[i]);
    }
    free(F);
    F = NULL;
}

template<typename dt_type>
void deallocate(dt_type**** F, size_t s1, size_t s2, size_t s3){
    size_t i, j, l;
    for(i = 0; i < s1; i++){
        for(j = 0; j < s2; j++){
            for(l = 0; l < s3; l++){
                free(F[i][j][l]);
            }
            free(F[i][j]);
        }
        free(F[i]);
    }
    free(F);
    F = NULL;
}


/******************************
 * sycl based alloc functions
 * shared allocation 
 * of void type
*/

template<typename dt_type>
void allocate_shared(sycl::queue q, dt_type *F, size_t s1){
    F = sycl::malloc_shared<dt_type>(s1,q);
}

template<typename dt_type>
void allocate_shared(sycl::queue q,dt_type** F, size_t s1, size_t s2){
    F = sycl::malloc_shared<dt_type*>(s1,q);
    for(int i=0;i<s1;i++){
        F[i] = sycl::malloc_shared<dt_type>(s2,q);
    }
}

template<typename dt_type>
void allocate_shared(sycl::queue q, dt_type*** F, size_t s1, size_t s2, size_t s3){
    F = sycl::malloc_shared<dt_type**>(s1,q);
    int i, j ;
    for(i=0;i<s1;i++){
        F[i] = sycl::malloc_shared<dt_type*>(s2,q);
        for(j=0;j<s2;j++){
            F[i][j] = sycl::malloc_shared<dt_type>(s3,q);
        }
    }
}


/******************************
 * sycl based alloc functions
 * device allocation
*/

template<typename dt_type>
dt_type* allocate_device(sycl::queue q, size_t s1){
    dt_type *F = sycl::malloc_device<dt_type>(s1,q);
    q.wait();
    //q.submit([&](sycl::handler& h) {
    //    h.parallel_for(sycl::range<1>(s1), [=] (sycl::id<1> id){
    //        F[id] = 0 ;
    //    });
    //}).wait();
    return F ;
}

template<typename dt_type>
dt_type** allocate_device(sycl::queue q, size_t s1, size_t s2){
    dt_type** F = sycl::malloc_device<dt_type*>(s1,q);
    for(int i=0;i<s1;i++){
        F[i] = sycl::malloc_device<dt_type>(s2,q);
    }
    q.wait();
    //q.submit([&](sycl::handler& h) {
    //    h.parallel_for(sycl::range<2>(s1,s2), [=] (sycl::id<2> id){
    //        F[id[0]][id[1]] = 0 ;
    //    });
    //}).wait();
    return F ;
}

template<typename dt_type>
dt_type*** allocate_device(sycl::queue q, size_t s1, size_t s2, size_t s3){
    dt_type*** F = sycl::malloc_device<dt_type**>(s1,q);
    int i, j ;
    for(i=0;i<s1;i++){
        F[i] = sycl::malloc_device<dt_type*>(s2,q);
        for(j=0;j<s2;j++){
            F[i][j] = sycl::malloc_device<dt_type>(s3,q);
        }
    }
    q.wait();
    //q.submit([&](sycl::handler& h) {
    //    h.parallel_for(sycl::range<3>(s1,s2,s3), [=] (sycl::id<3> id){
    //        F[id[0]][id[1]][id[2]] = 0 ;
    //    });
    //}).wait();
    return F ;
}

/******************************
 * sycl based alloc functions
 * shared allocation
*/

template<typename dt_type>
dt_type* allocate_shared(sycl::queue q, size_t s1){
    dt_type *F = sycl::malloc_shared<dt_type>(s1,q);
    q.wait();
    //q.submit([&](sycl::handler& h) {
    //    h.parallel_for(sycl::range<1>(s1), [=] (sycl::id<1> id){
    //        F[id] = 0 ;
    //    });
    //}).wait();
    return F ;
}

template<typename dt_type>
dt_type** allocate_shared(sycl::queue q, size_t s1, size_t s2){
    dt_type** F = sycl::malloc_shared<dt_type*>(s1,q);
    for(int i=0;i<s1;i++){
        F[i] = sycl::malloc_shared<dt_type>(s2,q);
    }
    q.wait();
    //q.submit([&](sycl::handler& h) {
    //    h.parallel_for(sycl::range<2>(s1,s2), [=] (sycl::id<2> id){
    //        F[id[0]][id[1]] = 0 ;
    //    });
    //}).wait();
    return F ;
}

template<typename dt_type>
dt_type*** allocate_shared(sycl::queue q, size_t s1, size_t s2, size_t s3){
    dt_type*** F = sycl::malloc_shared<dt_type**>(s1,q);
    int i, j ;
    for(i=0;i<s1;i++){
        F[i] = sycl::malloc_shared<dt_type*>(s2,q);
        for(j=0;j<s2;j++){
            F[i][j] = sycl::malloc_shared<dt_type>(s3,q);
        }
    }
    q.wait();
    //q.submit([&](sycl::handler& h) {
    //    h.parallel_for(sycl::range<3>(s1,s2,s3), [=] (sycl::id<3> id){
    //        F[id[0]][id[1]][id[2]] = 0 ;
    //    });
    //}).wait();
    return F ;
}


/******************************
 * sycl based alloc functions
 * deallocation
*/

template<typename dt_type>
void deallocate(sycl::queue q, dt_type** F, size_t s1){
    for(int i=0;i<s1;i++){
        sycl::free(F[i], q);
    }
    sycl::free(F,q);
    F = NULL ;
}

template<typename dt_type>
void deallocate(sycl::queue q, dt_type*** F, size_t s1, size_t s2){
    for(int i=0;i<s1;i++){
        deallocate(q,F[i],s2);
    }
    sycl::free(F,q);
    F = NULL ;
}



/******************************
 * generalized functions
*/

template<typename dt_type>
dt_type* allocate(sycl::queue q, size_t s1){
    if(PFM::DEVICE::is_iGPU){
        return allocate_shared<dt_type>(q, s1);
    }else{
        return allocate_device<dt_type>(q, s1);
    }
}


template<typename dt_type>
dt_type** allocate(sycl::queue q, size_t s1, size_t s2){
    if(PFM::DEVICE::is_iGPU){
        return allocate_shared<dt_type>(q, s1, s2) ;
    }else{
        return allocate_device<dt_type>(q, s1, s2);
    }
}

template<typename dt_type>
dt_type*** allocate(sycl::queue q, size_t s1, size_t s2, size_t s3){
    if(PFM::DEVICE::is_iGPU){
        return allocate_shared<dt_type>(q, s1, s2, s3);
    }else{
        return allocate_device<dt_type>(q, s1, s2, s3);
    }
}

}// end of namespace


#endif