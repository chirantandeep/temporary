#ifndef syclenvfunch_
#define syclenvfunch_

#include <CL/sycl.hpp>
#include <bits/stdc++.h>

#include "pfm_global.h"

namespace utility{

sycl::queue get_cpu(){
    return sycl::queue(sycl::cpu_selector_v);
}

sycl::queue get_gpu(){
    return sycl::queue(sycl::gpu_selector_v);
}

sycl::queue get_queue(){
    if(PFM::DEVICE::is_iCPU){
        return get_cpu() ;
    }else if(PFM::DEVICE::is_iGPU){
        return get_gpu() ;
    }else{
        exit(0);
    }
}

void print_device_info(sycl::queue q){
    std::cout << "## Runing on:\n   " <<
    q.get_device().get_info<sycl::info::device::name>() << "\n";
}

inline void sycl_env_info(){
    int i = 0 , j = 0;
    std::cout << "## sycl_env_info\n" ;
    for (auto platform : sycl::platform::get_platforms()){
        std::cout << "platform " << i++ << ": "
                  << platform.get_info<sycl::info::platform::name>()
                  << std::endl;
        j = 0 ;
        for (auto device : platform.get_devices()){
            std::cout << "\tdevice " << j++ << ": "
                      << device.get_info<sycl::info::device::name>()
                      << std::endl;
        }
    }
}

/// @brief The function selects the best device availabe.
/// @return the best device
sycl::device get_best_device(){
    sycl::device d;
    /// Need a better algorithm to get the best available device
    try {
        d = sycl::device(sycl::gpu_selector_v);
    }
    catch (sycl::exception const &e) {
        d = sycl::device(sycl::cpu_selector_v);
    }
    std::cout << "\n## get_best_device :\n\t selected: "
              << d.get_info<sycl::info::device::name>() << "\n" ;
    return d ;
}
/**
 * memory copy functions
*/
template<typename dt_type>
inline void mem_copy(sycl::queue q, 
                    dt_type* dest_arr, 
                    dt_type* src_arr, 
                    size_t s1){
    if(PFM::DEVICE::is_iGPU){
        #pragma parallel ivdep
        for(size_t id = 0; id < s1; id++){
            dest_arr[id] = src_arr[id] ;
        }
    }else{
        q.submit([&](sycl::handler& h) {
        //h.memcpy(dest_arr, src_arr, (size_t)s1*sizeof(dt_type));
            h.parallel_for(sycl::range<1>(s1), [=] (sycl::id<1> id){
                dest_arr[id] = src_arr[id] ;
            });
        }).wait();
    }
}

template<typename dt_type>
inline void mem_copy(dt_type* dest_arr, 
                    dt_type* src_arr, 
                    size_t s1){
    #pragma parallel ivdep
    for(size_t id = 0 ; id < s1; id ++){ 
        dest_arr[id] = src_arr[id] ;
    }
}

template<typename dt_type>
inline void mem_copy(sycl::queue q, 
                    dt_type** dest_arr, 
                    dt_type* src_arr, 
                    size_t s1, 
                    size_t s2){
    #pragma parallel ivdep
    for(int i=0;i<s1;i++){
        mem_copy<dt_type>(q, dest_arr[i], src_arr + i*s2, s2);
    }
}

template<typename dt_type>
inline void mem_copy(
                    dt_type** dest_arr, 
                    dt_type* src_arr, 
                    size_t s1, 
                    size_t s2){
    #pragma parallel ivdep
    for(int i=0;i<s1;i++){
        mem_copy<dt_type>(dest_arr[i], src_arr + i*s2, s2);
    }
}


template<typename dt_type>
inline void mem_copy(sycl::queue q, 
                    dt_type* dest_arr, 
                    dt_type** src_arr, 
                    size_t s1, 
                    size_t s2){
    for(int i=0;i<s1;i++){
        mem_copy<dt_type>(q, dest_arr + i*s2, src_arr[i],s2);
    }
}

template<typename dt_type>
inline void mem_copy(
                    dt_type* dest_arr, 
                    dt_type** src_arr, 
                    size_t s1, 
                    size_t s2){
    #pragma parallel ivdep 
    for(int i=0;i<s1;i++){
        mem_copy<dt_type>(dest_arr + i*s2, src_arr[i],s2);
    }
}

template<typename dt_type>
inline void mem_copy(sycl::queue q, 
                    dt_type** dest_arr, 
                    dt_type** src_arr, 
                    size_t s1, 
                    size_t s2){
    for(int i=0;i<s1;i++){
        mem_copy(q, dest_arr[i], src_arr[i], s2);
    }
}

template<typename dt_type>
inline void mem_copy(
                    dt_type** dest_arr, 
                    dt_type** src_arr, 
                    size_t s1, 
                    size_t s2){
    #pragma parallel ivdep
    for(int i=0;i<s1;i++){
        mem_copy(dest_arr[i], src_arr[i], s2);
    }
}


template<typename dtType>
void printDevArr(sycl::queue q, dtType * Fdev, size_t s, std::string arrname,  std::ofstream &ofs){
    
    auto Fhost = alloc::allocate<dtType>(s) ;
    mem_copy(q, Fhost, Fdev, s) ;
    q.wait();
    
    for(int i=0;i<s;i++){
        ofs << arrname + "[" << i << "] = " << Fhost[i]  << ";\n";
    }
}

template<typename dtType>
void printDevArr(sycl::queue q, dtType * Fdev, size_t s, std::string filename){
    
    auto Fhost = alloc::allocate<dtType>(s) ;
    mem_copy(q, Fhost, Fdev, s) ;
    q.wait();
    std::ofstream out("./DATA/" + filename + ".csv");
    
    for(int i=0;i<s;i++){
        out << filename + "[" << i << "] = " << Fhost[i]  << ";\n";
    }
    out.close();
}

template<typename dtType>
void printArr(dtType * F, size_t s, std::string filename){

    std::ofstream out("./DATA/" + filename + ".csv");
    
    for(int i=0;i<s;i++){
        out << filename + "[" << i << "] = " << F[i]  << ";\n";
    }
    out.close();

}

template<typename dtType>
void printDevArr(sycl::queue q, dtType * Fdev, sycl::int3 ir, std::string filename, size_t c){
    size_t s = ir[0]*ir[1]*ir[2] ;
    auto Fhost = alloc::allocate<dtType>(s) ;
    mem_copy(q, Fhost, Fdev, s) ;
    q.wait();
    std::ofstream out("./DATA/" + filename +"_" + std::to_string(c) + ".vtk");

    out << "# vtk DataFile Version 3.0\n" ;
    out << "Microsim_fields\n" ;
    out << "ASCII\n" ;
    out << "DATASET STRUCTURED_POINTS\n" ;
    out << "DIMENSIONS " << ir[0] << " " << ir[1] << " " << ir[2] << "\n" ;
    out << "ORIGIN 0 0 0\n" ;
    out << "SPACING 1e-8 1e-8 1e-8\n";
    out << "POINT_DATA " << s << "\n" ;
    out << "SCALARS " << filename << " double 1\n";
    out << "LOOKUP_TABLE default\n" ;

    int i,j,k;
    int index;
    for(i=0;i<ir[0];i++){
        for(j=0;j<ir[1];j++){
            for(k=0;k<ir[2];k++){
                index = k + j*ir[2] + i*ir[2]*ir[1] ;
                out << std::scientific << Fhost[index] << "\n";
            }
        }
    }
    out << "\n";
    out.close();

    //sycl:free(Fhost,q);
    //Fhost = nullptr ;
}

template<typename dtType>
void printDevArr(sycl::queue q, dtType ** Fdev, size_t s, sycl::int3 ir, std::string filename, size_t c){
    for(int i=0;i<s;i++){
        printDevArr<dtType>(q, Fdev[i], ir, filename + std::to_string(i), c);
    }
    
}

double get_exec_time(sycl::event event1)
{
    double end = event1.get_profiling_info<sycl::info::event_profiling::command_end>();
    double start = event1.get_profiling_info<sycl::info::event_profiling::command_start>();
    return (end-start)/1.0e9 ;
    
}

}

#endif