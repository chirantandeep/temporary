/**
 * A SYCL wrapped KKS code majorlyderrived from the MicroSim CUDA solver. 
 * Runs always in 3D and only yet withc functionF = 4 ;
**/

#include <CL/sycl.hpp>
#include <bits/stdc++.h>
#include <mpi.h> 

#include "utility.h"
#include "structures.h"
#include "utilityFunctions.h"
#include "matrix.h"

#include "alloc.h"
#include "inputReader.h"
#include "initialize_variables.h"
#include "filling.h"
#include "fileWriter.h"

#include "io.h"
#include "enqueue.h"

#include "smooth.h"
#include "calcPhaseComp.h"
#include "utility_kernels.h"
#include "computeDrivingForce.h"
#include "updatePhi.h"
#include "updateComposition.h"
#include "boundary.h"

#include "test.h"

using namespace alloc;
using namespace utility ;
using namespace MicroSim ;
using namespace std::chrono;

int main(int argc, char *argv[]){
    std::string profile_file = argv[4] ;
    profile_file += "profiling.csv";
    std::ofstream profile_out(profile_file);

    auto start = high_resolution_clock::now();

    MPI_Init(&argc, &argv); 
    MPI_Comm comm = MPI_COMM_WORLD;
    int MPI_Enabled = false;
    int rank, size;
    MPI_Comm_size(comm, &size);
    MPI_Comm_rank(comm, &rank);

    //sycl_env_info() ;
    //auto d = get_best_device() ;
    auto q = get_cpu();
    print_device_info(q);

    domainInfo      simDomain;
    controls        simControls; 
    simParameters   simParams;
    fillParameters  simFill;
    subdomainInfo   subdomain;

    // Phase-field variables on host-side
    double *phi;
    double *comp;
    double *mu;

    mkdir("DATA", 0777);
    
    std::cout << "## Reading parameters\tstart\n";
    // Read input from specified input file
    readInput(  
        q,
        &simDomain,
        &simControls,
        &simParams,
        argv);

    readBoundaryConditions(
        &simDomain,
        &simControls,
        &simParams,
        argv);

    calcFreeEnergyCoeffs(
        &simDomain,
        &simControls,
        &simParams);

    moveParamsToGPU(
        q,
        &simDomain,
        &simControls,
        &simParams);

    decomposeDomain(
        simDomain,
        &simControls,
        &subdomain,
        rank,
        size);

    std::cout << "## Reading parameters\tdone\n";
    size_t np  = simDomain.numPhases ;
    size_t nc  = simDomain.numComponents ;
    size_t ncc = subdomain.numCompCells ;
    sycl::int3 iter_ranges = {  subdomain.sizeX,
                                subdomain.sizeY,
                                subdomain.sizeZ };
    phi  = allocate<double>(np     * ncc);
    comp = allocate<double>((nc-1) * ncc);

    std::cout << "## Filling domain\tstart\n";
    readFill(&simFill, argv);
    fillDomain(simDomain, subdomain, simParams, phi, comp, &simFill);
    std::cout << "## Filling domain\tdone\n";

    q.wait();
    std::cout << "## Device allocation\tstart\n";
    auto compDev         = allocate<double>(q, nc-1,     ncc);
    auto compNewDev      = allocate<double>(q, nc-1,     ncc);
    auto phiDev          = allocate<double>(q, np,       ncc);
    auto dfdphiDev       = allocate<double>(q, np,       ncc);
    auto phiNewDev       = allocate<double>(q, np,       ncc);
    auto phaseCompDev    = allocate<double>(q, np*(nc-1),ncc);
    double** muDev ;

    std::cout << "## Device allocation\tdone\n";
    // Move fields from host to device
    std::cout << "## Fill device arrays\tstart\n";
    mem_copy(q, phiDev,     phi,    np,     ncc);
    mem_copy(q, compDev,    comp,   nc-1,   ncc);

    q.wait() ;
    mem_copy(q, phiNewDev,  phiDev, np,     ncc);
    mem_copy(q, compNewDev, compDev,nc-1,   ncc);
    q.wait();
    std::cout << "## Fill device arrays\tdone\n";
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    sycl::range<3> ir = sycl::range<3>(subdomain.sizeX, subdomain.sizeY, subdomain.sizeZ);
    sycl::range<3> ir0 = sycl::range<3>(subdomain.sizeX-2, subdomain.sizeY-2, subdomain.sizeZ-2);

    /**
     * Declare all the necessary kernels
    */
    std::cout << "## Declaring kernels\tstart\n";
    auto smooth = smooth_kernel(phiDev, phiNewDev, &simDomain, &simControls, &simParams, &subdomain);

    auto calcPhaseComp = calcPhaseComp_kernel(phiDev, compDev, phaseCompDev, muDev, &simDomain, &simControls, &simParams, &subdomain) ;

    auto resetArr_dfdphi = resetArray_kernel(dfdphiDev, simDomain.numPhases, simDomain.DIMENSION, subdomain.sizeX, subdomain.sizeY, subdomain.sizeZ);

    auto computeDrivingForce = computeDrivingForce_Chemical_kernel(phiDev, compDev, dfdphiDev, phaseCompDev, muDev, &simDomain, &simControls, &simParams, &subdomain);

    auto updatePhi = updatePhi_kernel(phiDev, dfdphiDev, phiNewDev, phaseCompDev, &simDomain, &simControls, &simParams, &subdomain);

    auto updateComp = updateComposition_kernel(phiDev, compDev, phiNewDev, compNewDev, phaseCompDev, muDev, &simDomain, &simControls, &simParams, &subdomain);

    auto phiBC = boundaryCondition_kernel(phiDev,0,np, &simDomain, &simControls, &simParams, &subdomain);

    auto phiNewBC = boundaryCondition_kernel(phiNewDev,0,np, &simDomain, &simControls, &simParams, &subdomain);

    auto compBC = boundaryCondition_kernel(compDev, 2, nc-1, &simDomain, &simControls, &simParams, &subdomain);

    auto compNewBC = boundaryCondition_kernel(compNewDev, 2, nc-1, &simDomain, &simControls, &simParams, &subdomain);

    std::cout << "## Declaring kernels\tdone\n";
    std::cout << "## Apply initial BC\tstart\n";
    enq::enqueue(q, ir, phiBC) ;
    enq::enqueue(q, ir, phiNewBC) ;
    enq::enqueue(q, ir, compBC) ;
    enq::enqueue(q, ir, compNewBC) ;
    q.wait();
    std::cout << "## Apply initial BC\tdone\n";

    // Profiling count :
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    profile_out << "num_cells,num_steps,microseconds\n";
    profile_out << ncc << "," << "-1,"<< duration.count() << std::endl  ; 

    std::cout << "## Smooth run\tstart\n";
    for(int j=0;j<simControls.nsmooth;j++){
        
        enq::enqueue(q, ir0, smooth).wait();
        enq::enqueue(q, ir0, calcPhaseComp).wait();
        mem_copy(q, phiDev, phiNewDev,  np,     ncc);
        q.wait();
        enq::enqueue(q, ir, phiBC).wait() ;
        enq::enqueue(q, ir, phiNewBC).wait() ;
        //if (j % simControls.saveInterval == 0){
        //printDevArr(q, phiNewDev,  np,   iter_ranges, "phismooth", j);
        //q.wait();
        //}
    }
    std::cout << "## Smooth run\tdone\n";
    mem_copy(q, phiNewDev, phiDev,  np,     ncc);
    q.wait();
    /**
     * Solution timeloop
    */
    std::cout << "## Solution timeloop\tstart\n";
    for (simControls.count = 0; simControls.count <= simControls.numSteps; simControls.count++)
    {
        // Copy new field to old field
        mem_copy(q, phiDev,  phiNewDev,  np,     ncc);
        mem_copy(q, compDev, compNewDev, nc-1,   ncc);
        q.wait();

        if (simControls.count % simControls.saveInterval == 0 || simControls.count == simControls.numSteps){
            stop = high_resolution_clock::now();
            duration = duration_cast<microseconds>(stop - start);
            std::cout << "- Saving iter " << simControls.count << " in " 
                      << duration.count()/1e6 << " seconds" << std::endl ;
            profile_out << ncc << "," << simControls.count << "," << duration.count() << std::endl  ; 
            mem_copy(q, phi,    phiDev,  np,     ncc);
            mem_copy(q, comp,   compDev, nc-1,   ncc);
            q.wait();
            writeVTK_ASCII(phi, comp, mu, simDomain, subdomain, simControls, rank, comm, argv);
            //size_t sc = simControls.count ;
            //printDevArr(q, phiDev,     np,   iter_ranges, "phiDev",  sc );
            //printDevArr(q, phiNewDev,  np,   iter_ranges, "phiNewDev", sc);
            //printDevArr(q, compDev,    nc-1, iter_ranges, "compDev", sc);
            //printDevArr(q, compNewDev, nc-1, iter_ranges, "compNewDev", sc);
            //printDevArr(q, dfdphiDev,  np,   iter_ranges, "dfdphiDev", sc);
            //printDevArr(q, phaseCompDev,np*(nc-1),iter_ranges,"phaseCompDev",sc);
        } // print loop
        // modified
        enq::enqueue(q, ir, phiBC).wait() ;
        enq::enqueue(q, ir, compBC).wait() ;

        enq::enqueue(q, ir0, calcPhaseComp).wait();
        enq::enqueue(q, ir,  resetArr_dfdphi).wait();
        enq::enqueue(q, ir0, computeDrivingForce).wait();

        enq::enqueue(q, ir0, updatePhi).wait();
        enq::enqueue(q, ir,  phiNewBC).wait() ;

        enq::enqueue(q, ir0, updateComp).wait();
        enq::enqueue(q, ir,  compNewBC).wait();
                
    }
    std::cout << "## Solution timeloop\tdone\n";


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    std::cout << "## Dealocation\tstart\n";
    freeVars(&simDomain, &simControls, &simParams);
    free(phi) ;
    free(comp);
    deallocate(q, compDev, nc-1) ;
    deallocate(q, compNewDev, nc-1);
    deallocate(q, phiDev, np);
    deallocate(q, dfdphiDev, np);
    deallocate(q, phiNewDev, np);
    deallocate(q, phaseCompDev, np*(nc-1));
    std::cout << "## Dealocation\tdone\n";
    MPI_Finalize();
    return EXIT_SUCCESS ;
}