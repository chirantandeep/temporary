#ifndef FILEWRITER_H_
#define FILEWRITER_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>
#include <endian.h>


#include "structures.h"

namespace MicroSim{

/*
 * Files from each MPI process can not be merged and read directly
 * Reconstruct vtk files into a single vtk file if needed (resource-intensive)
 * Writes only .vtk files in each DATA/Processor_%d directory
 * N phases and C-1 components are written
 */

void writeVTK_BINARY(double *phi, double *comp, double *mu,
                     domainInfo simDomain, subdomainInfo subdomain,
                     controls simControls, int rank, MPI_Comm comm,
                     char *argv[]){
                        exit(0);
                     }


int readVTK_BINARY(FILE *fp, double *phi, double *comp, double *mu,
                   domainInfo simDomain, subdomainInfo subdomain,
                   controls simControls){
                    exit(0);
                   }



// -----------------------------------------

void writeVTK_ASCII(double *phi, double *comp, double *mu,
                    domainInfo simDomain, subdomainInfo subdomain,
                    controls simControls, int rank, MPI_Comm comm,
                    char *argv[])
{
    FILE *fp;
    char name[100];

    long t = simControls.count;

    long x, y, z;

    //sprintf(name, "DATA/Processor_%d/%s_%ld.vtk", rank, argv[3], t);
    sprintf(name, "DATA/%s_%ld.vtk", argv[3], t);
    fp = fopen(name, "w");

    /*
     * Metadata required for the reader to understand the data's topology and format
     */
    fprintf(fp, "# vtk DataFile Version 3.0\n");
    fprintf(fp, "Microsim_fields\n");
    fprintf(fp, "ASCII\n");
    fprintf(fp, "DATASET STRUCTURED_POINTS\n");
    fprintf(fp, "DIMENSIONS %ld %ld %ld\n", subdomain.numY, subdomain.numX, subdomain.numZ);
    fprintf(fp, "ORIGIN 0 0 0\n");
    fprintf(fp, "SPACING %le %le %le\n", simDomain.DELTA_Y, simDomain.DELTA_X, simDomain.DELTA_Z);
    fprintf(fp, "POINT_DATA %ld\n", subdomain.numCells);
    for (int a = 0; a < simDomain.numPhases; a++)
    {
        fprintf(fp, "SCALARS %s double 1\n", simDomain.phaseNames[a]);
        fprintf(fp, "LOOKUP_TABLE default\n");

        for (x = subdomain.xS_r; x < subdomain.xE_r; x++)
        {
            for (y = subdomain.yS_r; y < subdomain.yE_r; y++)
            {
                for (z = subdomain.zS_r; z < subdomain.zE_r; z++)
                {
                    fprintf(fp, "%le\n", phi[a*subdomain.numCompCells + x*subdomain.xStep + y*subdomain.yStep + z]);
                }
            }
        }

        fprintf(fp, "\n");
    }

    for (int b = 0; b < simDomain.numComponents-1; b++)
    {
        fprintf(fp, "SCALARS Composition_%s double 1\n", simDomain.componentNames[b]);
        fprintf(fp, "LOOKUP_TABLE default\n");

        for (x = subdomain.xS_r; x < subdomain.xE_r; x++)
        {
            for (y = subdomain.yS_r; y < subdomain.yE_r; y++)
            {
                for (z = subdomain.zS_r; z < subdomain.zE_r; z++)
                {
                    fprintf(fp, "%le\n", comp[b*subdomain.numCompCells + x*subdomain.xStep + y*subdomain.yStep + z]);
                }
            }
        }
        fprintf(fp, "\n");
    }

    if (simControls.FUNCTION_F == 2)
    {
        for (int b = 0; b < simDomain.numComponents-1; b++)
        {
            fprintf(fp, "SCALARS Mu_%s double 1\n", simDomain.componentNames[b]);
            fprintf(fp, "LOOKUP_TABLE default\n");

            for (x = subdomain.xS_r; x < subdomain.xE_r; x++)
            {
                for (y = subdomain.yS_r; y < subdomain.yE_r; y++)
                {
                    for (z = subdomain.zS_r; z < subdomain.zE_r; z++)
                    {
                        fprintf(fp, "%le\n", mu[b*subdomain.numCompCells + x*subdomain.xStep + y*subdomain.yStep + z]);
                    }
                }
            }
            fprintf(fp, "\n");
        }
    }

    fclose(fp);
}

int readVTK_ASCII(FILE *fp, double *phi, double *comp, double *mu,
                  domainInfo simDomain, subdomainInfo subdomain,
                  controls simControls)
{
    char temp[1000];
    long a = 0, k1 = 0, k2 = 0, x, y, z;
    //double value;

    long temp_mx = 0, temp_my = 0, temp_mz = 0;

    //long layer_size = subdomain.sizeX*subdomain.sizeY;

    while(fscanf(fp, "%s", temp))
    {
        if (strcmp(temp, "DIMENSIONS") == 0)
        {
            if(fscanf(fp, "%ld", &temp_my)){;}
            if(fscanf(fp, "%ld", &temp_mx)){;}
            if(fscanf(fp, "%ld", &temp_mz)){;}

            //             printf("Read dimensions: %d, %d, %d\n", temp_mx, temp_my, temp_mz);
            //             printf("Required dimensions: %d, %d, %d\n", (subdomain.xE-subdomain.xS+1), (subdomain.yE-subdomain.yS+1), (subdomain.zE-subdomain.zS+1));

            if (temp_mx != (subdomain.numX) || temp_my != (subdomain.numY) || temp_mz != (subdomain.numZ))
            {
                printf("Dimensions do not match. Filling using specified filling file\n");
                return 0;
            }
        }
        else if (strcmp(temp, "SPACING") == 0)
        {
            double temp_dx = 0, temp_dy = 0, temp_dz = 0;

            if(fscanf(fp, "%le", &temp_dy)){;}
            if(fscanf(fp, "%le", &temp_dx)){;}
            if(fscanf(fp, "%le", &temp_dz)){;}

            if (temp_dx != simDomain.DELTA_X || temp_dy != simDomain.DELTA_Y || temp_dz != simDomain.DELTA_Z)
            {
                printf("Dimensions do not match. Filling using specified filling file\n");
                return 0;
            }
        }
        else if (strcmp(temp, "default") == 0 && a < simDomain.numPhases)
        {
            for (x = subdomain.xS_r; x < subdomain.xE_r; x++)
            {
                for (y = subdomain.yS_r; y < subdomain.yE_r; y++)
                {
                    for (z = subdomain.zS_r; z < subdomain.zE_r; z++)
                    {
                        if(fscanf(fp, "%le", &phi[a*subdomain.numCompCells + x*subdomain.xStep + y*subdomain.yStep + z])){;}
                    }
                }
            }
            a++;
        }
        else if (strcmp(temp, "default") == 0 && k1 < simDomain.numComponents-1 && a >= simDomain.numPhases)
        {
            for (x = subdomain.xS_r; x < subdomain.xE_r; x++)
            {
                for (y = subdomain.yS_r; y < subdomain.yE_r; y++)
                {
                    for (z = subdomain.zS_r; z < subdomain.zE_r; z++)
                    {
                        if(fscanf(fp, "%le", &comp[k1*subdomain.numCompCells + x*subdomain.xStep + y*subdomain.yStep + z])){;}
                    }
                }
            }
            k1++;
        }
        else if (strcmp(temp, "default") == 0 && k2 < simDomain.numComponents-1 && k1 >= simDomain.numComponents-1 && a >= simDomain.numPhases && simControls.FUNCTION_F == 2)
        {
            for (y = subdomain.yS_r; y < subdomain.yE_r; y++)
            {
                for (x = subdomain.xS_r; x < subdomain.xE_r; x++)
                {
                    for (z = subdomain.zS_r; z < subdomain.zE_r; z++)
                    {
                        if(fscanf(fp, "%le", &mu[k2*subdomain.numCompCells + x*subdomain.xStep + y*subdomain.yStep + z])){;}
                    }
                }
            }
            k2++;
        }
        else if ((k2 == simDomain.numComponents-1 && simControls.FUNCTION_F == 2) || (k1 == simDomain.numComponents-1 && simControls.FUNCTION_F != 2))
            break;
    }

    return 1;
}

void readDomain(double *phi, double *comp, double *mu,
                 domainInfo simDomain, subdomainInfo subdomain,
                 controls simControls, int rank, MPI_Comm comm,
                 char *argv[])
{
    FILE *fp;
    char name[1000], writeformat[10];

    long t = simControls.count;

    int size;
    MPI_Comm_size(comm, &size);

    // Ensure numprocs = numfiles
    if (rank == size-1)
    {
        //sprintf(name,"DATA/Processor_%d/%s_%ld.vtk", rank+1, argv[3], t);
        sprintf(name,"DATA/%s_%ld.vtk", argv[3], t);
        if ( (fp = fopen(name, "rb")) )
        {
            printf("Found files that are not being read. Either move those files or change the number of processors\n");
            printf("File name in violation: %s\n", name);
            exit(-1);
        }
    }
    MPI_Barrier(comm);

    //sprintf(name,"DATA/Processor_%d/%s_%ld.vtk", rank, argv[3], t);
    sprintf(name,"DATA/%s_%ld.vtk", argv[3], t);

    if ( (fp = fopen(name, "rb")) )
    {
        if (rank == 0 || rank == size-1)
            printf("\nReading from %s\n", name);

        if(fscanf(fp, "%*[^\n]\n")){;}
        if(fscanf(fp, "%*[^\n]\n")){;}

        if(fscanf(fp, "%s", writeformat)){;}

        if (strcmp(writeformat, "ASCII") == 0)
        {
            if (readVTK_ASCII(fp, phi, comp, mu, simDomain, subdomain, simControls))
            {
                printf("Read %s successfully\n", name);
            }
            else
            {
                printf("Verify input and saved files\n");
                exit(-1);
            }
        }
        else if (strcmp(writeformat, "BINARY") == 0)
        {
            if ( readVTK_BINARY(fp, phi, comp, mu, simDomain, subdomain, simControls) )
            {
                printf("Read %s successfully\n", name);
            }
            else
            {
                printf("Verify input and saved files\n");
                exit(-1);
            }
        }
        fclose(fp);
    }
    else
    {
        printf("\nCould not find %s.", name);
        exit(-1);
    }
}

void writeDoubleArrayToVTK(double *arr, char *dirName, char *fileName, long nx, long ny, long nz)
{
    char name[110];
    sprintf(name, "%s/%s.vtk", dirName, fileName);

    FILE *fp = fopen(name, "w");
    fprintf(fp, "# vtk DataFile Version 3.0\n");
    fprintf(fp, "Microsim_fields\n");
    fprintf(fp, "ASCII\n");
    fprintf(fp, "DATASET STRUCTURED_POINTS\n");
    fprintf(fp, "DIMENSIONS %ld %ld %ld\n", nx, ny, nz);
    fprintf(fp, "ORIGIN 0 0 0\n");
    fprintf(fp, "SPACING %le %le %le\n", 1.0f, 1.0f, 1.0f);
    fprintf(fp, "POINT_DATA %ld\n\n", nx*ny*nz);

    fprintf(fp, "SCALARS %s double 1\n", fileName);
    fprintf(fp, "LOOKUP_TABLE default\n");


    for (long x = 0; x < nx; x++)
    {
        for (long y = 0; y < ny; y++)
        {
            for (long z = 0; z < nz; z++)
            {
                fprintf(fp, "%le\n", arr[z + nz*y + ny*nz*x]);
            }
        }
    }

    fprintf(fp, "\n");

    fclose(fp);
}



}
#endif