#ifndef DEFINES_H_
#define DEFINES_H_

#define MAX_NUM_PHASES 3
#define MAX_NUM_COMP 3
#define MAX_NUM_PHASE_COMP 6

#endif