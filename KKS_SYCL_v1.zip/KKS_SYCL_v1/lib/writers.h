#ifndef filewritersh
#define filewritersh

#include "definitions.h"
using namespace dtypes;

namespace io{

static inline void write2csv(field F, sycl::uint3 ar, std::string filename){

    std::string full_filename = "./out/" + filename + ".csv" ;
    std::ofstream csvfile(full_filename) ;

    int rz = ar[0], ry = ar[1], rx = ar[2] ;
    int i,j,k;
    for(k=0;k<rz;k++){
        for(j=0;j<ry;j++){
            for(i=0;i<rx;i++){
                csvfile << std::setprecision(2) << F[k][j][i] ;
                if(i!=rx-1){ csvfile << "," ; }
            }
            if(j!=ry-1){ csvfile << "\n" ; }
        }
        if(k!=rz-1){ csvfile << "\n" ; }
    }
}

static inline void write2csv(pfield pF, uint32_t nf, sycl::uint3 ar, std::string filename){
    for(int id = 0 ; id< nf; id++){
        write2csv(pF[id], ar, filename + "_" + std::to_string(id));
    }
}

static inline void write2csv(ppfield ppF, uint32_t nf1, uint32_t nf2, sycl::uint3 ar, std::string filename){
    for(int id = 0 ; id< nf1; id++){
        write2csv(ppF[id],nf2, ar, filename + "_" + std::to_string(id));
    }
}


}




#endif