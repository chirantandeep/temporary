#ifndef allochfile
#define allochfile


namespace alloc{

template<typename dt_type>
dt_type* allocate(size_t s1){
    dt_type *F = (dt_type *)std::malloc(s1*sizeof(dt_type));
    for(int i=0;i<s1;i++){
        F[i] = 0 ;
    }
    return F ;
}

template<typename dt_type>
dt_type** allocate(size_t s1, size_t s2){
    dt_type **F = (dt_type **)std::malloc(s1*sizeof(dt_type*));
    for(int i=0;i<s1;i++){
        F[i] = allocate<dt_type>(s2);
    }
    return F ;
}

template<typename dt_type>
void deallocate(dt_type** F, size_t s1){
    for(int i=0;i<s1;i++){
        free(F[i]);
    }
    free(F);
    F = NULL ;
}


template<typename dt_type>
dt_type* allocate(sycl::queue q, size_t s1){
    dt_type *F = sycl::malloc_shared<dt_type>(s1,q);
    q.submit([&](sycl::handler& h) {
        h.parallel_for(sycl::range<1>(s1), [=] (sycl::id<1> id){
            F[id] = 0 ;
        });
    });
    return F ;
}

template<typename dt_type>
dt_type** allocate(sycl::queue q, size_t s1, size_t s2){
    dt_type** F = sycl::malloc_shared<dt_type*>(s1,q);
    for(int i=0;i<s1;i++){
        F[i] = sycl::malloc_shared<dt_type>(s2,q);
        q.submit([&](sycl::handler& h) {
        h.parallel_for(sycl::range<1>(s2), [=] (sycl::id<1> id){
            F[i][id] = 0 ;
        });});
    }
    return F ;
}

template<typename dt_type>
void deallocate(sycl::queue q, dt_type** F, size_t s1){
    for(int i=0;i<s1;i++){
        sycl::free(F[i], q);
    }
    sycl::free(F,q);
    F = NULL ;
}

template<typename dt_type>
dt_type*** allocate(sycl::queue q, size_t s1, size_t s2, size_t s3){
    dt_type*** F = sycl::malloc_shared<dt_type**>(s1,q);
    for(int i=0;i<s1;i++){
        F[i] = allocate<dt_type>(q,s2,s3);
    }
    return F ;
}

template<typename dt_type>
void deallocate(sycl::queue q, dt_type*** F, size_t s1, size_t s2){
    for(int i=0;i<s1;i++){
        deallocate(q,F[i],s2);
    }
    sycl::free(F,q);
    F = NULL ;
}

}


#endif