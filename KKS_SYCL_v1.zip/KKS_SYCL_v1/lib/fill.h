#ifndef _MICROSIM_SYCL_FILL_FILE_H_
#define _MICROSIM_SYCL_FILL_FILE_H_

#include "enqueue.h"

namespace fillers{

class sphere
{
public:
    double * field ;
    long r ;
    double fg ;
    double bg ;
    sphere( double * f, long _r, double _fg, double _bg) : field(f), r(_r), fg(_fg), bg(_bg) {}

    bool condition(long x, long y, long z) const {
        return ( x*x + y*y + z*z < r*r);
    }

    void operator()(sycl::item<3> id) const {
        long x = id[2] ;
        long y = id[1] ;
        long z = id[0] ;
        field[id.get_linear_id()] = condition(x,y,z) ? fg : bg ;
    }

};



template<typename dttype>
inline void spherical(sycl::queue q, dttype* F, size_t s, double fg, double bg){
    auto sp_k = sphere(F, s/2, fg, bg);
    enq::enqueue(q, sycl::range<3>(s,s,s), sp_k);
}

}

#endif