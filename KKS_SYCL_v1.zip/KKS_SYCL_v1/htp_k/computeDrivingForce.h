#ifndef COMPUTEDRIVINGFORCE_CUH_
#define COMPUTEDRIVINGFORCE_CUH_

#include "structures.h"
#include "utility_kernels.h"
#include "Thermo.h"
#include "matrix.h"
#include "functionF.h"
#include "functionW.h"
//#include "functionW_02.h"
#include "functionH.h"


/*
 * Explicit calculation of the right-hand side of the Allen-Cahn equation.
 * Evaluation of the mobility function in the Cahn-Hilliard equation.
 */

class computeDrivingForce_Chemical_kernel
{
public:
    long FUNCTION_F ;
    double **phi;
    double **comp;
    double **dfdphi;
    double **phaseComp;
    double **mu;
    double *F0_A;
    double *F0_B;
    double *F0_C;
    double molarVolume;
    double *theta_i; 
    double *theta_ij;
    double *theta_ijk;
    int ELASTICITY;
    double temperature;
    long *thermo_phase;
    long NUMPHASES;
    long NUMCOMPONENTS; 
    long DIMENSION;
    long sizeX; 
    long sizeY; 
    long sizeZ;
    long xStep; 
    long yStep; 
    long padding;


    computeDrivingForce_Chemical_kernel(
        double **_phi, double **_comp, double **_dfdphi,      double **_phaseComp, double **_mu, domainInfo* _simDomain, controls* _simControls, simParameters* _simParams, subdomainInfo* _subdomain)
    :   FUNCTION_F(_simControls->FUNCTION_F),
        phi(_phi),
        comp(_comp),
        dfdphi(_dfdphi),
        phaseComp(_phaseComp),
        mu(_mu),
        F0_A(_simParams->F0_A_dev),
        F0_B(_simParams->F0_B_dev), 
        F0_C(_simParams->F0_C_dev),
        molarVolume(_simParams->molarVolume),
        theta_i(_simParams->theta_i_dev), 
        theta_ij(_simParams->theta_ij_dev), 
        theta_ijk(_simParams->theta_ijk_dev),
        ELASTICITY(_simControls->ELASTICITY),
        temperature(_simParams->T),
        thermo_phase(_simDomain->thermo_phase_dev),
        NUMPHASES(_simDomain->numPhases), 
        NUMCOMPONENTS(_simDomain->numComponents), 
        DIMENSION(_simDomain->DIMENSION),
        sizeX(_subdomain->sizeX), 
        sizeY(_subdomain->sizeY),
        sizeZ(_subdomain->sizeZ),
        xStep(_subdomain->xStep), 
        yStep(_subdomain->yStep),
        padding(_subdomain->padding) {}


    template<typename syclidtype>
    inline void computeDrivingForce01(syclidtype  ID) const {
        long i = ID[2] + padding;
        long j = ID[1] + padding;
        long k = ID[0] + padding;
    
        long idx = i*xStep + j*yStep + k;

        /*
        * Calculate grand potential density for every phase
        */
        double psi = 0.0;

        double Bpq_hphi[MAX_NUM_PHASES];

        for (long p = 0; p < NUMPHASES; p++){ Bpq_hphi[p] = dfdphi[p][idx];}

        for (long phase = 0; phase < NUMPHASES; phase++) {
        if (ELASTICITY){
            dfdphi[phase][idx] = 0.0;

            for (long p = 0; p < NUMPHASES; p++)
                dfdphi[phase][idx] += calcInterp5thDiff(phi, phase, p, idx, NUMPHASES)*Bpq_hphi[p];
        }

        for (long p = 0; p < NUMPHASES; p++)
        {
        /*
            * \psi_{p} = f^{p} - \sum_{i=1}^{K-1} (c^{p}_{i}\mu_{i})
            */
        psi = 0.0;

        psi += calcPhaseEnergy(phaseComp, p, F0_A, F0_B, F0_C, idx, NUMPHASES, NUMCOMPONENTS);
        
        for (long component = 0; component < NUMCOMPONENTS-1; component++)
            psi -= calcDiffusionPotential(phaseComp, p, component, F0_A, F0_B, idx, NUMPHASES, NUMCOMPONENTS)*phaseComp[(component*NUMPHASES) + p][idx];

        /*
            * \frac{\delta F}{\delta\phi_{phase}} += \sum_{p=1}^{N} (\frac{\partial h(\phi_{p})}{\partial \phi_{phase}} \frac{\psi_{p}}{V_{m}})
            */
        psi *= calcInterp5thDiff(phi, p, phase, idx, NUMPHASES);

        dfdphi[phase][idx] += psi/molarVolume;
        }

        /*
            * Potential function
            * \frac{\delta F}{\delta\phi_{phase}} += \frac{\partial g(\phi_{phase})}{\partial\phi_{phase}}
            */
        dfdphi[phase][idx] += calcDoubleWellDerivative(phi, phase, theta_i, theta_ij, theta_ijk, idx, NUMPHASES);
        }

    }

    template<typename syclidtype>
    inline void computeDrivingForce02(syclidtype  ID) const {
        long i = ID[2];
        long j = ID[1];
        long k = ID[0];
        long idx = i*xStep + j*yStep + k;

    if (i < sizeX && ((j < sizeY && DIMENSION >= 2) || (DIMENSION == 1 && j == 0)) && ((k < sizeZ && DIMENSION == 3) || (DIMENSION < 3 && k == 0)))
    {
        /*
         * Calculate grand potential density for every phase
         */
        double y[MAX_NUM_COMP];
        double phaseEnergy = 0.0;
        double sum = 0.0;
        double psi = 0.0;

        double Bpq_hphi[MAX_NUM_PHASES];

        for (long p = 0; p < NUMPHASES; p++)
        {
            Bpq_hphi[p] = dfdphi[p][idx];
        }

        for (long phase = 0; phase < NUMPHASES; phase++)
        {
            if (ELASTICITY)
            {
                dfdphi[phase][idx] = 0.0;

                for (long p = 0; p < NUMPHASES; p++)
                    dfdphi[phase][idx] += calcInterp5thDiff(phi, phase, p, idx, NUMPHASES)*Bpq_hphi[p];
            }

            for (long p = 0; p < NUMPHASES; p++)
            {
                sum = 0.0;

                for (long is = 0; is < NUMCOMPONENTS-1; is++)
                {
                    y[is] = phaseComp[is*NUMPHASES + p][idx];
                    sum += y[is];
                }

                y[NUMCOMPONENTS-1] = 1.0 - sum;

                GEF(p,temperature, y, &phaseEnergy);

                //(*free_energy_tdb_dev[thermo_phase[p]])(temperature, y, &phaseEnergy);

                /*
                 * \psi_{p} = f^{p} - \sum_{i=1}^{K-1} (c^{p}_{i}\mu_{i})
                 */
                psi = 0.0;

                psi += phaseEnergy;
                for (long component = 0; component < NUMCOMPONENTS-1; component++)
                    psi -= mu[component][idx]*phaseComp[(component*NUMPHASES + p)][idx];


                /*
                 * \frac{\delta F}{\delta\phi_{phase}} += \sum_{p=1}^{N} (\frac{\partial h(\phi_{p})}{\partial \phi_{phase}} \frac{\psi_{p}}{V_{m}})
                 */
                psi *= calcInterp5thDiff(phi, p, phase, idx, NUMPHASES);
                dfdphi[phase][idx] += psi/molarVolume;
            }

            /*
             * Potential function
             * \frac{\delta F}{\delta\phi_{phase}} += \frac{\partial g(\phi_{phase})}{\partial\phi_{phase}}
             */
            dfdphi[phase][idx] += calcDoubleWellDerivative(phi, phase,
                                                           theta_i, theta_ij, theta_ijk,
                                                           idx, NUMPHASES);
        }
    }

    }

/*    
    template<typename syclidtype>
    void operator() (syclidtype  ID) const {
        if (FUNCTION_F == 1 || FUNCTION_F == 3  || FUNCTION_F == 4){
            computeDrivingForce01(ID) ;
        }else if (FUNCTION_F == 2){
            computeDrivingForce02(ID) ;
        }
    }
*/
    template<typename syclidtype>
    void operator() (syclidtype  ID) const {
        computeDrivingForce01(ID) ;
    }

};


#endif