#ifndef UTILITYKERNELS_CUH_
#define UTILITYKERNELS_CUH_

class computeChange_kernel
{
public:
    double *A;
    double *B;
    long DIMENSION;
    long sizeX;
    long sizeY;
    long sizeZ;
    computeChange_kernel(){}

};

class resetArray_kernel
{
public:
    double **arr;
    long numArr;
    long DIMENSION;
    long sizeX;
    long sizeY;
    long sizeZ;
    resetArray_kernel(
        double **_arr, long _numArr, long _DIMENSION, long _sizeX, long _sizeY, long _sizeZ)
            :arr(_arr),
            numArr(_numArr),
            DIMENSION(_DIMENSION),
            sizeX(_sizeX),
            sizeY(_sizeY),
            sizeZ(_sizeZ) {}

    template<typename syclidtype>
    void operator() (syclidtype ID) const {
        long k = ID[0],
            j  = ID[1],
            i  = ID[2];
        
        long idx = (j + i*sizeY)*sizeZ + k;

        if (i < sizeX && ((j < sizeY && DIMENSION >= 2) || (DIMENSION == 1 && j == 0)) && ((k < sizeZ && DIMENSION == 3) || (DIMENSION < 3 && k == 0)))
        {
            for (long iter = 0; iter < numArr; iter++)
                arr[iter][idx] = 0.0;
        }
        
    }

};





#endif