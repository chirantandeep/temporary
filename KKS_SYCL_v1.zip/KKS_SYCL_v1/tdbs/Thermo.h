/******************************************************************************
 *                       Code generated with sympy 1.8                        *
 *                                                                            *
 *              See http://www.sympy.org/ for more information.               *
 *                                                                            *
 *                       This file is part of 'project'                       *
 ******************************************************************************/


#ifndef PROJECT__TDBS_THERMO__H
#define PROJECT__TDBS_THERMO__H

inline void GE_0(double T, double *y, double *Ge);
inline void GE_1(double T, double *y, double *Ge);
inline void Mu_0(double T, double *y, double *Mu);
inline void Mu_1(double T, double *y, double *Mu);
inline void dmudc_0(double T, double *y, double *Dmudc);
inline void dmudc_1(double T, double *y, double *Dmudc);

inline void GEF(size_t s, double T, double *y, double *Ge){
    if(s == 0){
        GE_0(T, y, Ge) ;
    }else{
        GE_1(T, y, Ge) ;
    }
}

inline void MuF(size_t s, double T, double *y, double *Mu){
    if(s == 0){
        Mu_0(T, y, Mu) ;
    }else{
        Mu_1(T, y, Mu) ;
    }
}

inline void dmudcF(size_t s, double T, double *y, double *Dmudc){
    if(s == 0){
        dmudc_0(T, y, Dmudc) ;
    }else{
        dmudc_1(T, y, Dmudc) ;
    }
}

//inline void(*free_energy_tdb[])(double T, double *y, double *Ge) = {GE_0,GE_1}; 
//inline void(*Mu_tdb[])(double T, double *y, double *Mu) = {Mu_0,Mu_1}; 
//inline void(*dmudc_tdb[])(double T, double *y, double *Dmudc) = {dmudc_0,dmudc_1};

#include "Thermo.c"

#endif   

