## How to compile and run the KKS_SYCL_v2 program
- To run on a system where all dependencies are met globaly simply run
    ```
    make run
    ```
- To submit it as a job on Intel-Devcloud run:
    ```
    make run-devcloud
    ```
    >CAUTION: As `devcloud` does not have `gsl` installed you need to install it yourself. Follow the instructions under [this](#how-to-install-gsl-gnu-scientific-library-locally) header.

## Program Limitations
1. Only `FUNCTION_F=4` is available.
2. Only runs on `CPUs`

## How to install `gsl` (GNU Scientific Library) locally?
1. Download `gsl` package using the command
    ```
    git clone https://git.savannah.gnu.org/git/gsl.git
    ```
    This will create a directory named `gsl` in your `.`
2. Create the directory where you want to install `gsl` using the command
    ```
    mkdir /absolute/path/to/gsl
    ```
3. Run 
    ```
    ./configure --prefix=/absolute/path/to/gsl
    ```
    This tells the installer to install it in the path you gave.
4. Install with `make` as follows :
    ```
    make
    make check
    make install
    ```
5. Update the `Makefile` to include the newly installed gsl path by setting the `GSL_PATH` variable to `/absolute/path/to/gsl` as such
    ```
    GSL_PATH=/absolute/path/to/gsl
    ```