#include <CL/sycl.hpp>
#include <bits/stdc++.h>
#include <mpi.h>

#include "pfm_global.h"

#include "alloc.h"
#include "utility.h"
#include "structures.h"
#include "utilityFunctions.h"
#include "matrix.h"

#include "inputReader.h"
#include "initialize_variables.h"
#include "filling.h"
#include "fileWriter.h"

#include "io.h"
#include "enqueue.h"

#include "smooth.h"
#include "calcPhaseComp.h"
#include "utility_kernels.h"
#include "computeDrivingForce.h"
#include "updatePhi.h"
#include "updateComposition.h"
#include "boundary.h"

using namespace sycl;
using namespace alloc;
using namespace utility ;
using namespace MicroSim ;
using namespace std::chrono;

static const int N = 16;

int main(int argc, char ** argv){

    PFM_Init(&argc, &argv);

    /**
     * Check the command line argumemts
    */

    MPI_Init(&argc, &argv); 
    MPI_Comm comm = MPI_COMM_WORLD;
    int MPI_Enabled = false;
    int rank, size;
    MPI_Comm_size(comm, &size);
    MPI_Comm_rank(comm, &rank);

    //sycl_env_info() ;
    //auto d = get_best_device() ;
    auto q = get_queue();
    print_device_info(q);

    domainInfo      simDomain;
    controls        simControls; 
    simParameters   simParams;
    fillParameters  simFill;
    subdomainInfo   subdomain;

    // Phase-field variables on host-side
    double *phi;
    double *comp;
    double *mu;

    auto data = alloc::allocate<double>(q, 4, 4,4);
    std::cout << "allocation done\n";
    q.wait();
    q.parallel_for(range<3>(4,4,4), [=] (id<3> id){
        data[id[0]][id[1]][id[2]] *= 2;
    }).wait();

    auto sd = &simDomain ;
    auto sd1 = *sd ;
    auto arr_link = (*sd).thermo_phase_dev ;

    q.submit([&](sycl::handler& h) {
        h.single_task([=](){
        int i, j, k, l ;
        arr_link[0] = 0.0 ;
        });
    }).wait();
    std::cout << "enqueue done!\n";

 
    return 0;
}