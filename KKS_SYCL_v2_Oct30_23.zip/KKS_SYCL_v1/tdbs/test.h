#include "Thermo.h"

namespace test{
inline void thermo_functions(double T)
{
    double val = 0.0;
    double y[2] ;
    std::ofstream GEstream("./DATA/ge.csv");
    std::ofstream MUstream("./DATA/mu.csv");
    std::ofstream DMUDCstream("./DATA/dmudc.csv");

    int i ;

    for(double x=0; x<1; x+=1e-2){
        y[0] = x ;
        y[1] = 1.0-x ;

        for(i=0;i<2;i++){
            GEF(i,T,y, &val);
            GEstream << std::scientific << val << ",";
        }
        for(i=0;i<2;i++){
            MuF(i,T,y, &val);
            MUstream << std::scientific << val << ",";
        }
        for(i=0;i<2;i++){
            dmudcF(i,T,y, &val) ;
            DMUDCstream << std::scientific << val << ",";
        }
        GEstream << "\n";
        MUstream << "\n";
        DMUDCstream << "\n";
    }



}


}
