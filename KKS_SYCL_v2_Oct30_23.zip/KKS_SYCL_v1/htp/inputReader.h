#ifndef INPUTREADER_H_
#define INPUTREADER_H_

#include "pfm_global.h"
#include "structures.h"
#include "utilityFunctions.h"
#include "alloc.h"

namespace MicroSim{

int readInput(  sycl::queue q, 
                domainInfo *simDomain,
                controls *simControls,
                simParameters *simParams) ;

/*
 * Read and assign boundary conditions from the specified input file.
 */
void assignBufferPointsConditions(
    long j, int BOUNDARY_LEFT, int BOUNDARY_RIGHT,
    int BOUNDARY_FRONT, int BOUNDARY_BACK, int BOUNDARY_TOP,
    int BOUNDARY_BOTTOM, domainInfo *simDomain,
    controls *simControls, simParameters *simParams) ;

void initializeBoundaryConditions(
    char *tmpstr,
    domainInfo *simDomain,
    controls *simControls,
    simParameters *simParams) ;

void printBondaryConditions(
    FILE *fp, 
    domainInfo *simDomain, 
    controls *simControls,
    simParameters *simParams) ;


void readBoundaryConditions(
    domainInfo *simDomain,
    controls *simControls,
    simParameters *simParams);

/*
 * Reads filling parameters from the specified file.
 * The filling routines can be found in initialise.h and its
 * related files.
 */
void readFill(
    fillParameters *fill);

}

////////////////////////////
///////////////////////////
#include "reading_input_parameters.cpp"
#include "read_boundary_conditions.cpp"
#include "fill_domain.cpp"
#endif

