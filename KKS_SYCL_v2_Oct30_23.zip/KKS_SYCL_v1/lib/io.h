#ifndef PFM_SYCL_IO_FILE_H
#define PFM_SYCL_IO_FILE_H

#include "alloc.h"
#include "utility.h"

namespace io{

template <typename T>
inline void writeCSV(T** F, size_t sy, size_t sx, std::string filename){
    std::ofstream out(filename) ;
    std::string c ;
    for(int i=0; i<sy; i++){
    for(int j=0; j<sx; j++){
        out << F[i][j] ;
        c = (j!=sx-1) ? "," : "\n" ;
        out << c;
    }
    }
}


template <typename T>
inline void writeCSV(sycl::queue q, T** dev_arr, size_t sy, size_t sx){
    T** host_arr = alloc::allocate<T>(sy,sx);
    utility::mem_copy(q, host_arr, dev_arr, sy, sx);
}

}

#endif