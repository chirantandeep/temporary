#ifndef PFM_SYCL_ENQUEUE_H_FILE
#define PFM_SYCL_ENQUEUE_H_FILE

namespace enq{

template<class kernel_class>
inline sycl::event enqueue(
    sycl::queue q,
    sycl::range<3> ir,
    kernel_class K){
    return q.submit([&](sycl::handler& h){
            h.parallel_for(ir, K);
    });
}

}


#endif